ABN SENARA LOADER — سورس جديد

المحتويات:
- android-app: مشروع أندرويد Java بواجهة تسجيل دخول ثم لوحة اللودر.
- server: API Node.js للتحقق من الأكواد وإدارة أكواد مجانية/مدفوعة.

مهم:
1) هذا سورس مشروع، وليس APK جاهزاً. يلزم Android SDK/Gradle لبناء APK.
2) عدّل BASE_URL في MainActivity.java إلى رابط السيرفر المنشور مع https.
3) السيرفر يحتاج Node.js 18 أو أحدث.
4) شغّل السيرفر:
   cd server
   npm install
   cp .env.example .env
   عدّل ADMIN_TOKEN إلى قيمة سرية قوية
   npm start
5) أنشئ كوداً تجريبياً بعد تشغيل السيرفر:
   curl -X POST http://localhost:3000/admin/codes -H 'Content-Type: application/json' -H 'x-admin-token: CHANGE_ME' -d '{"type":"free","days":7,"count":1}'
   غيّر CHANGE_ME إلى ADMIN_TOKEN الموجود في .env. سيظهر الكود في استجابة الأمر.
6) انشر السيرفر على استضافة HTTPS قبل استعمال التطبيق خارج جهازك.

اللودر لا يحقن ملفات في الألعاب ولا يتجاوز أنظمة الحماية. أزرار الألعاب تحاول فتح اللعبة المثبتة، وقد تحتاج تعديل أسماء الحزم حسب نسختك.
حقوق الواجهة: SENARA ©
