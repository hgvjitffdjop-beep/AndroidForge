const express = require('express');
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');
const app = express(); app.use(express.json({limit:'16kb'}));
const DB = path.join(__dirname,'codes.json'); const PORT=process.env.PORT||3000; const ADMIN_TOKEN=process.env.ADMIN_TOKEN||'';
function read(){try{return JSON.parse(fs.readFileSync(DB,'utf8'))}catch{return {codes:[]}}}
function write(db){fs.writeFileSync(DB,JSON.stringify(db,null,2),{mode:0o600})}
function admin(req,res,next){const got=req.get('x-admin-token')||'';if(!ADMIN_TOKEN||!crypto.timingSafeEqual(Buffer.from(got.padEnd(128,' ').slice(0,128)),Buffer.from(ADMIN_TOKEN.padEnd(128,' ').slice(0,128))))return res.status(401).json({error:'unauthorized'});next()}
function newCode(){return 'SENARA-'+crypto.randomBytes(5).toString('hex').toUpperCase()}
app.get('/health',(req,res)=>res.json({ok:true,service:'ABN SENARA activation API'}));
app.post('/api/verify',(req,res)=>{const code=String(req.body?.code||'').trim().toUpperCase();if(!code||code.length>100)return res.status(400).json({valid:false,message:'أدخل كوداً صحيحاً'});const db=read();const item=db.codes.find(x=>x.code===code);if(!item||item.revoked)return res.status(200).json({valid:false,message:'الكود غير صالح أو معطل'});if(item.expiresAt&&Date.now()>Date.parse(item.expiresAt))return res.status(200).json({valid:false,message:'انتهت صلاحية الكود'});if(item.device&&req.body?.device&&item.device!==req.body.device)return res.status(200).json({valid:false,message:'الكود مرتبط بجهاز آخر'});if(!item.device&&req.body?.device)item.device=String(req.body.device).slice(0,120);item.lastUsedAt=new Date().toISOString();write(db);res.json({valid:true,type:item.type,expiresAt:item.expiresAt||null});});
app.post('/admin/codes',admin,(req,res)=>{const type=req.body?.type==='paid'?'paid':'free';const days=Math.max(1,Math.min(3650,Number(req.body?.days)||7));const count=Math.max(1,Math.min(100,Number(req.body?.count)||1));const db=read(), created=[];for(let i=0;i<count;i++){let code;do{code=newCode()}while(db.codes.some(x=>x.code===code));const item={code,type,createdAt:new Date().toISOString(),expiresAt:new Date(Date.now()+days*86400000).toISOString(),revoked:false,device:null};db.codes.push(item);created.push(item)}write(db);res.status(201).json({created});});
app.get('/admin/codes',admin,(req,res)=>res.json({codes:read().codes.map(({code,type,createdAt,expiresAt,revoked,device,lastUsedAt})=>({code,type,createdAt,expiresAt,revoked,device,lastUsedAt}))}));
app.post('/admin/revoke',admin,(req,res)=>{const code=String(req.body?.code||'').toUpperCase();const db=read(),item=db.codes.find(x=>x.code===code);if(!item)return res.status(404).json({error:'not_found'});item.revoked=true;write(db);res.json({ok:true,code});});
app.listen(PORT,'0.0.0.0',()=>{if(!fs.existsSync(DB))write({codes:[]});console.log(`Activation API listening on ${PORT}`)});
