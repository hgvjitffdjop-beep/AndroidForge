سيرفر الأكواد — SENARA

المتطلبات: Node.js 18+
1) انسخ .env.example إلى .env، واجعل ADMIN_TOKEN سراً طويلاً وفريداً.
2) npm install ثم npm start.
3) لا تترك ADMIN_TOKEN الافتراضي، ولا تستخدم HTTP على الإنترنت. انشر خلف HTTPS.

إنشاء كود مجاني لمدة 7 أيام:
curl -X POST http://localhost:3000/admin/codes -H "Content-Type: application/json" -H "x-admin-token: YOUR_SECRET" -d '{"type":"free","days":7,"count":1}'

إنشاء كود مدفوع لمدة 30 يوماً:
curl -X POST http://localhost:3000/admin/codes -H "Content-Type: application/json" -H "x-admin-token: YOUR_SECRET" -d '{"type":"paid","days":30,"count":5}'

عرض الأكواد:
curl http://localhost:3000/admin/codes -H "x-admin-token: YOUR_SECRET"

تعطيل كود:
curl -X POST http://localhost:3000/admin/revoke -H "Content-Type: application/json" -H "x-admin-token: YOUR_SECRET" -d '{"code":"SENARA-..."}'

ملاحظة أمان: هذا نموذج أساس، وليس نظام دفع إلكتروني. النوع paid هو تصنيف إداري فقط ولا يثبت استلام دفعة. أضف بوابة دفع وسياسة حماية مناسبة قبل الاستخدام التجاري. ملف codes.json ينشأ تلقائياً ولا ترفعه إلى مستودع عام.
