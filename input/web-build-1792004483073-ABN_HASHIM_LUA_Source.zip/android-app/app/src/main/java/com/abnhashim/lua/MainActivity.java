package com.abnhashim.lua;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(8, 13, 31);
    private final int wine = Color.rgb(91, 12, 38);
    private final int gold = Color.rgb(225, 174, 71);
    private final int white = Color.rgb(239, 239, 245);
    // Replace with your deployed HTTPS endpoint, e.g. https://your-domain.example/verify
    private static final String VERIFY_URL = "https://YOUR-SERVER-DOMAIN/verify";

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        showLogin();
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(22);
        d.setStroke(2, stroke); return d;
    }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(12, 10, 12, 10);
        return t;
    }
    private LinearLayout page() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(22, 26, 22, 24); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        return root;
    }
    private void showLogin() {
        LinearLayout root = page();
        root.addView(label("✦  ABN HASHIM  ✦", 27, gold));
        root.addView(label("// LUA ACCESS SYSTEM //", 14, white));
        Space sp = new Space(this); root.addView(sp, new LinearLayout.LayoutParams(1, 35));
        root.addView(label("LOGIN WITH ACTIVATION KEY", 18, gold));
        EditText key = new EditText(this);
        key.setSingleLine(true); key.setHint("Enter activation code");
        key.setHintTextColor(Color.LTGRAY); key.setTextColor(white);
        key.setPadding(18, 14, 18, 14); key.setBackground(shape(Color.rgb(20, 25, 43), gold));
        root.addView(key, new LinearLayout.LayoutParams(-1, -2));
        TextView btn = label("VERIFY & CONTINUE", 16, white);
        btn.setBackground(shape(wine, gold));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = 18;
        root.addView(btn, bp);
        TextView note = label("Secure activation • ABN HASHIM", 12, Color.LTGRAY);
        root.addView(note);
        btn.setOnClickListener(v -> {
            String entered = key.getText().toString().trim();
            if (entered.isEmpty()) { key.setError("Enter your activation code"); return; }
            new AlertDialog.Builder(this).setTitle("Server not configured")
              .setMessage("Set VERIFY_URL to your deployed HTTPS server and connect the verification API before using real activation codes.")
              .setPositiveButton("OK", null).show();
        });
    }

    private void showDashboard() {
        LinearLayout root = page();
        root.addView(label("✦ ABN HASHIM // LUA ✦", 25, gold));
        root.addView(label("GAME VERSION SELECTOR", 13, white));
        addGame(root, "PUBG MOBILE GLOBAL", "com.tencent.ig");
        addGame(root, "PUBG MOBILE KOREA", "com.pubg.krmobile");
        addGame(root, "PUBG MOBILE VIETNAM", "com.vng.pubgmobile");
        addGame(root, "PUBG MOBILE TAIWAN", "com.rekoo.pubgm");
        addGame(root, "PUBG FLASH", "REPLACE_WITH_FLASH_PACKAGE");
    }
    private void addGame(LinearLayout root, String title, String pkg) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setPadding(12, 8, 12, 10);
        card.setBackground(shape(Color.rgb(17, 22, 39), wine));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = 12;
        root.addView(card, cp);
        card.addView(label(title, 16, gold));
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER);
        card.addView(row);
        addButton(row, "ENABLE", () -> toast("واجهة فقط: اربط وظيفتك المصرح بها هنا"));
        addButton(row, "REMOVE", () -> toast("لم تتم إضافة وظيفة إزالة إلى هذا السورس"));
        addButton(row, "LAUNCH", () -> launchPackage(pkg));
    }
    private void addButton(LinearLayout row, String text, Runnable action) {
        TextView b = label(text, 11, white); b.setBackground(shape(wine, gold));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 48, 1);
        p.setMargins(3, 4, 3, 4); row.addView(b, p); b.setOnClickListener(v -> action.run());
    }
    private void launchPackage(String pkg) {
        if (pkg.startsWith("REPLACE_")) { toast("أدخل اسم حزمة PUBG FLASH أولاً"); return; }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) startActivity(launch);
        else toast("اللعبة غير مثبتة أو اسم الحزمة غير صحيح");
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
