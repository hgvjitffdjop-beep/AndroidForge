const express = require("express");
const helmet = require("helmet");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(helmet());
app.use(express.json({ limit: "8kb" }));

const codesPath = path.join(__dirname, "codes.json");
function loadCodes() {
  try { return JSON.parse(fs.readFileSync(codesPath, "utf8")); }
  catch { return {}; }
}

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/verify", (req, res) => {
  const code = String(req.body?.code || "").trim();
  if (!code || code.length > 128) return res.status(400).json({ valid: false, error: "invalid_request" });

  const item = loadCodes()[code];
  if (!item || item.active !== true) return res.status(401).json({ valid: false, error: "invalid_code" });
  if (item.expiresAt && Date.parse(item.expiresAt) <= Date.now())
    return res.status(401).json({ valid: false, error: "expired" });

  return res.json({ valid: true, product: "ABN HASHIM // LUA", expiresAt: item.expiresAt || null });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`License API listening on ${port}`));
