تشغيل تجريبي للسيرفر:
1) ثبّت Node.js على بيئة استضافة تدعم Node.
2) انسخ codes.example.json إلى codes.json.
3) نفّذ npm install ثم npm start.
4) انشره خلف HTTPS، ثم غيّر VERIFY_URL في MainActivity.java.

التحقق:
POST /verify
Content-Type: application/json
{"code":"DEMO-ABN-7DAYS"}

تنبيه أمني:
- ملف codes.json تجريبي، ولا توجد لوحة إدارة أو قاعدة بيانات دائمة.
- لا تضع أسرار الإدارة في تطبيق Android.
- قبل الاستخدام الحقيقي أضف مصادقة إدارية، تخزيناً آمناً، rate limiting، نسخاً احتياطية، وتدوير مفاتيح.
- التطبيق الحالي لا يتصل بالسيرفر بعد؛ شاشة الدخول تعرض تنبيهاً حتى يكتمل ربط HTTPS واختباره.
