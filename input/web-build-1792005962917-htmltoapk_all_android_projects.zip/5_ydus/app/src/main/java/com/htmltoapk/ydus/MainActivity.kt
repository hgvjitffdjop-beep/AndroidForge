package com.htmltoapk.ydus

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.MimeTypeMap
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.URLUtil
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.widget.ProgressBar
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.addCallback
import androidx.activity.result.ActivityResultLauncher
import android.app.Dialog
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.updatePadding
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

private const val TAG = "WebViewActivity"
private const val PAGE_LOAD_TIMEOUT_MS = 20_000L
private const val CLEARTEXT_PROXY_PREFIX = "https://appassets.androidplatform.net/__cleartext_proxy__/?url="

private val CLEARTEXT_INTERCEPTOR_SCRIPT = """
    (function() {
        if (window.__htmlToApkCleartextHooked) return;
        window.__htmlToApkCleartextHooked = true;

        var PROXY_PREFIX = '$CLEARTEXT_PROXY_PREFIX';

        function toProxyUrl(url) {
            if (!url) return url;
            if (typeof url === 'string') {
                if (url.startsWith('http://')) {
                    return PROXY_PREFIX + encodeURIComponent(url);
                }
                return url;
            }
            try {
                var str = url.toString();
                if (str.startsWith('http://')) {
                    return PROXY_PREFIX + encodeURIComponent(str);
                }
            } catch (_) {}
            return url;
        }

        function fromProxyUrl(url) {
            if (!url || typeof url !== 'string') return url;
            if (url.startsWith(PROXY_PREFIX)) {
                try {
                    return decodeURIComponent(url.substring(PROXY_PREFIX.length));
                } catch (_) {}
            }
            return url;
        }

        if (typeof window.fetch === 'function') {
            var origFetch = window.fetch;
            window.fetch = function(input, init) {
                try {
                    if (typeof input === 'string') {
                        input = toProxyUrl(input);
                    } else if (typeof URL !== 'undefined' && input instanceof URL) {
                        input = toProxyUrl(input.toString());
                    } else if (input && typeof input.url === 'string' && input.url.startsWith('http://')) {
                        var newUrl = toProxyUrl(input.url);
                        input = new Request(newUrl, input);
                    }
                } catch (_) {}
                return origFetch.call(this, input, init);
            };
        }

        if (typeof window.XMLHttpRequest === 'function') {
            var origOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
                this.__originalUrl = url;
                var proxied = toProxyUrl(typeof url === 'string' ? url : (url ? url.toString() : url));
                return origOpen.call(this, method, proxied, async !== false, user, password);
            };
        }

        try {
            var mediaProto = window.HTMLMediaElement && window.HTMLMediaElement.prototype;
            if (mediaProto) {
                var mediaSrcDesc = Object.getOwnPropertyDescriptor(mediaProto, 'src');
                if (mediaSrcDesc && mediaSrcDesc.set) {
                    var origMediaSet = mediaSrcDesc.set;
                    var origMediaGet = mediaSrcDesc.get;
                    Object.defineProperty(mediaProto, 'src', {
                        get: function() {
                            return fromProxyUrl(origMediaGet.call(this));
                        },
                        set: function(val) {
                            return origMediaSet.call(this, toProxyUrl(val));
                        },
                        configurable: true,
                        enumerable: true
                    });
                }
                var currentSrcDesc = Object.getOwnPropertyDescriptor(mediaProto, 'currentSrc');
                if (currentSrcDesc && currentSrcDesc.get) {
                    var origCurrentSrcGet = currentSrcDesc.get;
                    Object.defineProperty(mediaProto, 'currentSrc', {
                        get: function() {
                            return fromProxyUrl(origCurrentSrcGet.call(this));
                        },
                        configurable: true,
                        enumerable: true
                    });
                }
            }
        } catch (_) {}

        try {
            var sourceProto = window.HTMLSourceElement && window.HTMLSourceElement.prototype;
            if (sourceProto) {
                var sourceSrcDesc = Object.getOwnPropertyDescriptor(sourceProto, 'src');
                if (sourceSrcDesc && sourceSrcDesc.set) {
                    var origSourceSet = sourceSrcDesc.set;
                    var origSourceGet = sourceSrcDesc.get;
                    Object.defineProperty(sourceProto, 'src', {
                        get: function() {
                            return fromProxyUrl(origSourceGet.call(this));
                        },
                        set: function(val) {
                            return origSourceSet.call(this, toProxyUrl(val));
                        },
                        configurable: true,
                        enumerable: true
                    });
                }
            }
        } catch (_) {}

        try {
            var origSetAttr = Element.prototype.setAttribute;
            var origGetAttr = Element.prototype.getAttribute;
            Element.prototype.setAttribute = function(name, val) {
                if (typeof name === 'string' && name.toLowerCase() === 'src') {
                    var tag = this.tagName ? this.tagName.toLowerCase() : '';
                    if (tag === 'video' || tag === 'audio' || tag === 'source' || tag === 'img' || tag === 'iframe') {
                        val = toProxyUrl(val);
                    }
                }
                return origSetAttr.call(this, name, val);
            };
            Element.prototype.getAttribute = function(name) {
                var val = origGetAttr.call(this, name);
                if (typeof name === 'string' && name.toLowerCase() === 'src' && val) {
                    return fromProxyUrl(val);
                }
                return val;
            };
        } catch (_) {}

        function rewriteMediaElement(el) {
            try {
                if (!el || !el.getAttribute) return;
                var rawSrc = el.getAttribute('src');
                if (rawSrc && rawSrc.startsWith('http://')) {
                    el.src = toProxyUrl(rawSrc);
                }
            } catch (_) {}
        }

        function rewriteExistingTags() {
            try {
                var mediaEls = document.querySelectorAll('video, audio, source, img, iframe');
                for (var i = 0; i < mediaEls.length; i++) {
                    rewriteMediaElement(mediaEls[i]);
                }
            } catch (_) {}
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', rewriteExistingTags);
        } else {
            rewriteExistingTags();
        }

        try {
            if (typeof MutationObserver !== 'undefined') {
                var observer = new MutationObserver(function(mutations) {
                    for (var m = 0; m < mutations.length; m++) {
                        var mutation = mutations[m];
                        if (mutation.type === 'childList') {
                            for (var a = 0; a < mutation.addedNodes.length; a++) {
                                var node = mutation.addedNodes[a];
                                if (node.nodeType === 1) {
                                    var tag = node.tagName ? node.tagName.toLowerCase() : '';
                                    if (tag === 'video' || tag === 'audio' || tag === 'source' || tag === 'img' || tag === 'iframe') {
                                        rewriteMediaElement(node);
                                    }
                                    if (node.querySelectorAll) {
                                        var children = node.querySelectorAll('video, audio, source, img, iframe');
                                        for (var c = 0; c < children.length; c++) {
                                            rewriteMediaElement(children[c]);
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
                observer.observe(document.documentElement || document, { childList: true, subtree: true });
            }
        } catch (_) {}
    })();
""".trimIndent()

class MainActivity : ComponentActivity() {

    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private var toolbar: View? = null
    private var toolbarTitle: android.widget.TextView? = null
    private var noInternetDialog: Dialog? = null
    private var lastPageLoadFailed = false
    private lateinit var splashView: ImageView
    lateinit var webView: WebView
        private set
    private lateinit var previewView: PreviewView
    private var customVideoView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    private lateinit var androidApi: AndroidAPI
    private lateinit var adMobBridge: AdMobBridge
    private lateinit var displayConfig: DisplayConfig
    private lateinit var cameraExecutor: ExecutorService

    private val jsEventEmitter: (String, JSONObject) -> Unit = { event, data ->
        if (::androidApi.isInitialized) {
            androidApi.emit(event, data)
        }
    }
    private var bannerPaddingTop = 0
    private var bannerPaddingBottom = 0
    private var cachedUserAgent: String = ""

    fun updateBannerPadding(visible: Boolean, isTop: Boolean) {
        val heightPx = if (visible) (50 * resources.displayMetrics.density).toInt() else 0
        if (isTop) {
            bannerPaddingTop = heightPx
        } else {
            bannerPaddingBottom = heightPx
        }
        runOnUiThread {
            val rootLayout: View? = findViewById(R.id.root_layout)
            if (rootLayout != null) {
                ViewCompat.requestApplyInsets(rootLayout)
            } else {
                val contentContainer: View? = findViewById(R.id.main_content_container)
                if (contentContainer != null) {
                    ViewCompat.requestApplyInsets(contentContainer)
                } else if (::swipeRefreshLayout.isInitialized) {
                    ViewCompat.requestApplyInsets(swipeRefreshLayout)
                }
            }
        }
    }

    private var assetLoader: WebViewAssetLoader? = null
    var launchDeepLink: String? = null
        private set
    private val pageLoadHandler = Handler(Looper.getMainLooper())
    private val pageLoadTimeoutRunnable = Runnable { onPageLoadTimedOut() }
    private var pageLoadFinished = false
    private var pendingCameraCallbackId: String? = null
    private var pendingPhotoFile: File? = null
    private var pendingFileCallbackId: String? = null
    private var pendingWriteCallbackId: String? = null
    private var pendingWriteContent: String? = null
    private var pendingPermissionCallbackId: String? = null
    private var pendingPermission: String? = null
    private var pendingPermissionsCallbackId: String? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var fileChooserLauncher: ActivityResultLauncher<Intent>

    data class DisplayConfig(
        val mode: String = "local",
        val url: String = "",
        val showHeader: Boolean = true,
        val showActionBar: Boolean = true,
        val keepScreenOn: Boolean = false,
        val showCameraCutout: Boolean = false,
        val desktopMode: Boolean = false,
        val pullToRefresh: Boolean = true,
        val noInternetDialog: Boolean = true,
        val loadingIndicator: Boolean = false,
        val backHistoryNavigation: Boolean = true,
        val exitConfirmationDialog: Boolean = false,
        val orientation: String = "portrait",
        val primaryColor: String = "#2196F3",
        val hasSplash: Boolean = false,
        val showWatermark: Boolean = false,
        val isPro: Boolean = false,
        val permissions: List<String> = emptyList(),
        val webViewSettings: WebViewSettings = WebViewSettings(),
        val admobEnabled: Boolean = false,
        val admobAppId: String = "",
        val admobBannerUnitId: String = "",
        val admobInterstitialUnitId: String = "",
        val admobRewardedUnitId: String = "",
        val admobBannerPosition: String = "bottom",
        val admobShowBannerOnStart: Boolean = false,
        val admobTestDeviceIds: List<String> = emptyList(),
        val admobAutoLoadInterstitial: Boolean = false,
        val admobAutoLoadRewarded: Boolean = false,
        val admobUseTestAds: Boolean = false,
        val admobBannerEnabled: Boolean = false,
        val admobInterstitialEnabled: Boolean = false,
        val admobRewardedEnabled: Boolean = false,
        val admobInterstitialIntervalSeconds: Int = 0,
        val admobInterstitialPageCount: Int = 0
    )

    data class WebViewSettings(
        val javaScriptEnabled: Boolean = true,
        val domStorageEnabled: Boolean = true,
        val allowFileAccess: Boolean = false,
        val allowContentAccess: Boolean = false,
        val allowUniversalAccessFromFileURLs: Boolean = true,
        val allowFileAccessFromFileURLs: Boolean = true,
        val builtInZoomControls: Boolean = true,
        val displayZoomControls: Boolean = false,
        val useWideViewPort: Boolean = true,
        val loadWithOverviewMode: Boolean = true,
        val cacheMode: Int = WebSettings.LOAD_DEFAULT,
        val mixedContentMode: Int = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE,
        val userAgent: String? = null,
        val textZoom: Int = 100,
        val geolocationEnabled: Boolean = false
    )

    private var pendingWebPermissionRequest: PermissionRequest? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val camCallbackId = pendingCameraCallbackId
        if (camCallbackId != null && pendingPermission == Manifest.permission.CAMERA) {
            pendingPermission = null
            if (granted) {
                launchCameraIntent(camCallbackId)
            } else {
                pendingCameraCallbackId = null
                androidApi.onCameraResult(camCallbackId, false, null)
            }
            return@registerForActivityResult
        }
        val callbackId = pendingPermissionCallbackId ?: return@registerForActivityResult
        androidApi.onPermissionResult(callbackId, pendingPermission ?: "", granted)
        pendingPermissionCallbackId = null
        pendingPermission = null
    }

    private val multiplePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val webRequest = pendingWebPermissionRequest
        if (webRequest != null) {
            pendingWebPermissionRequest = null
            val allGranted = webRequest.resources.all { res ->
                when (res) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> results[Manifest.permission.CAMERA] == true ||
                            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> results[Manifest.permission.RECORD_AUDIO] == true ||
                            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    else -> true
                }
            }
            runOnUiThread {
                if (allGranted) {
                    webRequest.grant(webRequest.resources)
                } else {
                    webRequest.deny()
                }
            }
            return@registerForActivityResult
        }
        val callbackId = pendingPermissionsCallbackId ?: return@registerForActivityResult
        androidApi.onPermissionsResult(callbackId, results)
        pendingPermissionsCallbackId = null
    }

    private val launchPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Launch-time permissions are best-effort; individual APIs still request when needed.
    }

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        val callbackId = pendingCameraCallbackId
        val file = pendingPhotoFile
        pendingCameraCallbackId = null
        pendingPhotoFile = null
        if (callbackId == null) return@registerForActivityResult
        if (!success || file == null || !file.exists()) {
            androidApi.onCameraResult(callbackId, false, null)
            return@registerForActivityResult
        }
        Thread {
            try {
                val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                android.graphics.BitmapFactory.decodeFile(file.absolutePath, bounds)

                val reqMax = 1600
                var inSample = 1
                val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
                while (maxDim / inSample > reqMax) {
                    inSample *= 2
                }

                val opts = android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = inSample
                    inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                }
                var bitmap = android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)

                try {
                    val exif = android.media.ExifInterface(file.absolutePath)
                    val orientation = exif.getAttributeInt(
                        android.media.ExifInterface.TAG_ORIENTATION,
                        android.media.ExifInterface.ORIENTATION_NORMAL
                    )
                    val matrix = android.graphics.Matrix()
                    when (orientation) {
                        android.media.ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                        android.media.ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                        android.media.ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    }
                    if (bitmap != null && !matrix.isIdentity) {
                        val rotated = android.graphics.Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                        if (rotated != bitmap) {
                            bitmap.recycle()
                            bitmap = rotated
                        }
                    }
                } catch (_: Throwable) {}

                val stream = ByteArrayOutputStream()
                bitmap?.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, stream)
                bitmap?.recycle()
                val bytes = stream.toByteArray()
                val base64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                try { file.delete() } catch (_: Throwable) {}
                runOnUiThread {
                    androidApi.onCameraResult(callbackId, true, "data:image/jpeg;base64,$base64")
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Error processing captured photo", t)
                try { file.delete() } catch (_: Throwable) {}
                runOnUiThread {
                    androidApi.onCameraResult(callbackId, false, null)
                }
            }
        }.start()
    }

    private val pickFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        val callbackId = pendingFileCallbackId
        pendingFileCallbackId = null
        if (callbackId == null) return@registerForActivityResult
        if (uri == null) {
            androidApi.onFilePicked(callbackId, null, "Cancelled")
            return@registerForActivityResult
        }
        Thread {
            try {
                val content = readUriContent(uri)
                runOnUiThread {
                    androidApi.onFilePicked(callbackId, content, null)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    androidApi.onFilePicked(callbackId, null, e.message)
                }
            }
        }.start()
    }

    private val createDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        val callbackId = pendingWriteCallbackId
        val content = pendingWriteContent
        pendingWriteCallbackId = null
        pendingWriteContent = null
        if (callbackId == null) return@registerForActivityResult
        if (uri == null || content == null) {
            androidApi.onFileWritten(callbackId, false, "Cancelled")
            return@registerForActivityResult
        }
        Thread {
            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(content.toByteArray(Charsets.UTF_8))
                }
                runOnUiThread {
                    androidApi.onFileWritten(callbackId, true, null)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    androidApi.onFileWritten(callbackId, false, e.message)
                }
            }
        }.start()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        super.onCreate(savedInstanceState)
        actionBar?.hide()
        enableEdgeToEdge()
        cameraExecutor = Executors.newSingleThreadExecutor()

        fileChooserLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val callback = filePathCallback
            filePathCallback = null
            if (callback == null) return@registerForActivityResult
            val data = result.data
            val results: Array<Uri>? = when {
                result.resultCode != RESULT_OK || data == null -> null
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2 && data.clipData != null -> {
                    val clip = data.clipData!!
                    Array(clip.itemCount) { clip.getItemAt(it).uri }
                }
                data.data != null -> arrayOf(data.data!!)
                else -> null
            }
            callback.onReceiveValue(results)
        }

        displayConfig = readDisplayConfig()

        val requestedOrientation = when (displayConfig.orientation) {
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            "auto" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        if (requestedOrientation != ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED) {
            setRequestedOrientation(requestedOrientation)
        }

        if (displayConfig.keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        val allowCutout = !displayConfig.showActionBar && displayConfig.showCameraCutout
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (allowCutout) {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            } else {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER
            }
            window.attributes = lp
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val toolbarView: View = findViewById(R.id.toolbar)
        val titleView: android.widget.TextView = findViewById(R.id.toolbar_title)
        toolbar = toolbarView
        toolbarTitle = titleView
        if (displayConfig.showActionBar) {
            toolbarView.visibility = View.VISIBLE
            toolbarView.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            titleView.text = applicationInfo.loadLabel(packageManager)
            applyPrimaryColor(displayConfig.primaryColor, true)
        } else {
            toolbarView.visibility = View.GONE
            toolbarView.layoutParams.height = 0
            toolbarView.setPadding(0, 0, 0, 0)
        }

        val insetsController = WindowInsetsControllerCompat(window, window.decorView)
        if (displayConfig.showActionBar) {
            val primaryColor = try {
                android.graphics.Color.parseColor(displayConfig.primaryColor)
            } catch (e: Exception) {
                android.graphics.Color.BLACK
            }
            insetsController.isAppearanceLightStatusBars =
                androidx.core.graphics.ColorUtils.calculateLuminance(primaryColor) > 0.5
        } else {
            insetsController.isAppearanceLightStatusBars = false
        }
        insetsController.isAppearanceLightNavigationBars = false

        if (!displayConfig.showHeader) {
            insetsController.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
            insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        val rootLayout: FrameLayout = findViewById(R.id.root_layout)
        val contentContainer: LinearLayout = findViewById(R.id.main_content_container)
        swipeRefreshLayout = findViewById(R.id.swipe_refresh)
        webView = findViewById(R.id.webview)
        progressBar = findViewById(R.id.progress_bar)
        splashView = findViewById(R.id.splash_view)
        previewView = findViewById(R.id.preview_view)
        val watermarkView: android.widget.TextView = findViewById(R.id.watermark_view)
        watermarkView.visibility = if (displayConfig.showWatermark) android.view.View.VISIBLE else android.view.View.GONE

        val isUrlMode = displayConfig.mode == "url"
        val isLocalMode = !isUrlMode

        if (isUrlMode && displayConfig.pullToRefresh) {
            swipeRefreshLayout.isEnabled = true
            swipeRefreshLayout.setOnRefreshListener {
                webView.reload()
            }
        } else {
            swipeRefreshLayout.isEnabled = false
        }

        adMobBridge = AdMobBridge(this, displayConfig, jsEventEmitter)
        androidApi = AndroidAPI(this, displayConfig.isPro, adMobBridge)

        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { _, insets ->
            val systemBars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            val cutout = insets.getInsets(WindowInsetsCompat.Type.displayCutout())
            val statusBarHeight = maxOf(cutout.top, systemBars.top)

            val isActionBarVisible = displayConfig.showActionBar && toolbar?.visibility != View.GONE
            // Aksiyon çubuğu açıksa çentik özelliği otomatik olarak görmezden gelinir!
            val effectiveShowCameraCutout = if (isActionBarVisible) false else displayConfig.showCameraCutout

            if (isActionBarVisible) {
                // Aksiyon çubuğu açık:
                // Durum çubuğu görünürse Toolbar'a üst dolgu verilir (böylece primaryColor durumu kaplar)
                val tbTopPadding = if (displayConfig.showHeader) statusBarHeight else 0
                toolbar?.visibility = View.VISIBLE
                toolbar?.layoutParams?.height = ViewGroup.LayoutParams.WRAP_CONTENT
                toolbar?.setPadding(
                    maxOf(cutout.left, systemBars.left),
                    tbTopPadding,
                    maxOf(cutout.right, systemBars.right),
                    0
                )

                // Web arayüzü doğrudan aksiyon çubuğunun bitiminden itibaren başlar
                swipeRefreshLayout.setPadding(
                    maxOf(cutout.left, systemBars.left),
                    bannerPaddingTop,
                    maxOf(cutout.right, systemBars.right),
                    systemBars.bottom + bannerPaddingBottom
                )
            } else {
                // Aksiyon çubuğu kapalı:
                toolbar?.visibility = View.GONE
                toolbar?.layoutParams?.height = 0
                toolbar?.setPadding(0, 0, 0, 0)

                val padTop = if (effectiveShowCameraCutout) {
                    bannerPaddingTop
                } else {
                    val safeTop = if (displayConfig.showHeader) statusBarHeight else maxOf(cutout.top, systemBars.top)
                    safeTop + bannerPaddingTop
                }

                val padLeft = if (effectiveShowCameraCutout) 0 else maxOf(cutout.left, systemBars.left)
                val padRight = if (effectiveShowCameraCutout) 0 else maxOf(cutout.right, systemBars.right)
                val padBottom = systemBars.bottom + bannerPaddingBottom

                swipeRefreshLayout.setPadding(
                    padLeft,
                    padTop,
                    padRight,
                    padBottom
                )
            }

            if (::adMobBridge.isInitialized) {
                adMobBridge.updateBannerMargins()
            }
            WindowInsetsCompat.CONSUMED
        }

        rootLayout.post {
            ViewCompat.requestApplyInsets(rootLayout)
        }

        onBackPressedDispatcher.addCallback(this) {
            if (customVideoView != null) {
                hideCustomView()
                return@addCallback
            }
            if (previewView.visibility == View.VISIBLE) {
                stopCameraPreview()
                return@addCallback
            }
            if (isUrlMode && displayConfig.backHistoryNavigation && webView.canGoBack()) {
                webView.goBack()
                return@addCallback
            }
            if (displayConfig.exitConfirmationDialog) {
                IosDialogHelper.showExitConfirmation(this@WebViewActivity) {
                    finish()
                }
                return@addCallback
            }
            finish()
        }

        val settings = displayConfig.webViewSettings
        webView.settings.apply {
            javaScriptEnabled = settings.javaScriptEnabled
            domStorageEnabled = settings.domStorageEnabled
            // databaseEnabled is required by some WebView implementations for
            // localStorage persistence even though it is deprecated.
            @Suppress("DEPRECATION")
            databaseEnabled = settings.domStorageEnabled
            allowFileAccess = isLocalMode && settings.allowFileAccess
            allowContentAccess = isLocalMode && settings.allowContentAccess
            // Local HTML needs these to call remote APIs (fetch/XHR) without CORS blocks.
            setAllowUniversalAccessFromFileURLs(isLocalMode && settings.allowUniversalAccessFromFileURLs)
            setAllowFileAccessFromFileURLs(isLocalMode && settings.allowFileAccessFromFileURLs)
            useWideViewPort = settings.useWideViewPort
            loadWithOverviewMode = settings.loadWithOverviewMode
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            mediaPlaybackRequiresUserGesture = false
            if (displayConfig.desktopMode) {
                val rawUa = userAgentString ?: ""
                val desktopUa = rawUa
                    .replace("Mobile", "")
                    .replace("Android", "")
                    .replace("; wv", "")
                    .trim()
                userAgentString = if (desktopUa.isNotBlank() && !desktopUa.contains("Linux; ;")) {
                    desktopUa
                } else {
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                }
                useWideViewPort = true
                loadWithOverviewMode = true
            }
            setSupportZoom(settings.builtInZoomControls)
            builtInZoomControls = settings.builtInZoomControls
            displayZoomControls = settings.displayZoomControls
            cacheMode = settings.cacheMode
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            if (!settings.userAgent.isNullOrBlank()) {
                userAgentString = settings.userAgent
            }
            if (settings.textZoom != 100) {
                textZoom = settings.textZoom
            }
            setGeolocationEnabled(settings.geolocationEnabled)
        }

        cachedUserAgent = webView.settings.userAgentString ?: ""
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                WebViewCompat.addDocumentStartJavaScript(
                    webView,
                    CLEARTEXT_INTERCEPTOR_SCRIPT,
                    setOf("*")
                )
            } catch (e: Exception) {
                Log.w(TAG, "addDocumentStartJavaScript broad origins failed: ${e.message}")
                try {
                    WebViewCompat.addDocumentStartJavaScript(
                        webView,
                        CLEARTEXT_INTERCEPTOR_SCRIPT,
                        setOf("https://appassets.androidplatform.net")
                    )
                } catch (e2: Exception) {
                    Log.w(TAG, "addDocumentStartJavaScript fallback failed: ${e2.message}")
                }
            }
        }

        try {
            CookieManager.getInstance().apply {
                setAcceptCookie(true)
                setAcceptThirdPartyCookies(webView, true)
            }
        } catch (_: Exception) {}

        if (isLocalMode) {
            assetLoader = WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
                .build()
        }
        webView.addJavascriptInterface(androidApi, AndroidAPI.INTERFACE_NAME)

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                pageLoadFinished = false
                lastPageLoadFailed = false
                injectCleartextInterceptor()
                injectBlobDownloadInterceptor()
                if (isUrlMode && displayConfig.loadingIndicator) {
                    progressBar.visibility = ProgressBar.VISIBLE
                    progressBar.progress = 10
                } else {
                    progressBar.visibility = ProgressBar.GONE
                }
                pageLoadHandler.removeCallbacks(pageLoadTimeoutRunnable)
                pageLoadHandler.postDelayed(pageLoadTimeoutRunnable, PAGE_LOAD_TIMEOUT_MS)
                Log.d(TAG, "WebView page started: $url")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageLoadFinished = true
                pageLoadHandler.removeCallbacks(pageLoadTimeoutRunnable)
                progressBar.visibility = ProgressBar.GONE
                swipeRefreshLayout.isRefreshing = false
                // Hata oluştuysa veya ağ yoksa diyalogu kapatma; sadece başarılı yüklemede kapat
                if (!lastPageLoadFailed && isNetworkConnected()) {
                    if (noInternetDialog?.isShowing == true) {
                        noInternetDialog?.dismiss()
                        noInternetDialog = null
                    }
                }
                emitDeepLink()
                injectCleartextInterceptor()
                injectBlobDownloadInterceptor()
                if (::adMobBridge.isInitialized) adMobBridge.onPageLoaded()
                Log.d(TAG, "WebView page finished: $url")
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                Log.d(TAG, "WebView error on ${request?.url}: ${error?.description} (${error?.errorCode})")
                if (request?.isForMainFrame == true) {
                    swipeRefreshLayout.isRefreshing = false
                    lastPageLoadFailed = true
                    if (isUrlMode && displayConfig.noInternetDialog) {
                        showNoInternetDialog()
                    } else {
                        onPageLoadFailed(getString(R.string.error_page_load, error?.description ?: ""))
                    }
                }
            }

            override fun onReceivedHttpError(
                view: WebView?,
                request: WebResourceRequest?,
                errorResponse: WebResourceResponse?
            ) {
                super.onReceivedHttpError(view, request, errorResponse)
                Log.d(TAG, "WebView HTTP error on ${request?.url}: ${errorResponse?.statusCode}")
                if (request?.isForMainFrame == true) {
                    onPageLoadFailed(getString(R.string.error_server, errorResponse?.statusCode?.toString() ?: ""))
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                return handleExternalNavigation(request?.url)
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url ?: return super.shouldInterceptRequest(view, request)
                if (isLocalMode) {
                    val assetResponse = assetLoader?.shouldInterceptRequest(url)
                    if (assetResponse != null) {
                        val path = url.path ?: ""
                        val isHtml = assetResponse.mimeType?.contains("html", ignoreCase = true) == true ||
                                path.endsWith(".html", ignoreCase = true) ||
                                path.endsWith("/") ||
                                path == "/assets/www"
                        if (isHtml && assetResponse.data != null) {
                            try {
                                val rawBytes = assetResponse.data.use { it.readBytes() }
                                val htmlContent = rawBytes.toString(Charsets.UTF_8)
                                val scriptTag = "\n<script>\n$CLEARTEXT_INTERCEPTOR_SCRIPT\n</script>\n"
                                val headIdx = htmlContent.indexOf("<head>", ignoreCase = true)
                                val modifiedHtml = if (headIdx != -1) {
                                    val insertPos = headIdx + 6
                                    htmlContent.substring(0, insertPos) + scriptTag + htmlContent.substring(insertPos)
                                } else {
                                    val htmlIdx = htmlContent.indexOf("<html>", ignoreCase = true)
                                    if (htmlIdx != -1) {
                                        val insertPos = htmlIdx + 6
                                        htmlContent.substring(0, insertPos) + "<head>" + scriptTag + "</head>" + htmlContent.substring(insertPos)
                                    } else {
                                        scriptTag + htmlContent
                                    }
                                }
                                val headers = assetResponse.responseHeaders?.toMutableMap() ?: mutableMapOf()
                                headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
                                return WebResourceResponse(
                                    "text/html",
                                    "UTF-8",
                                    assetResponse.statusCode,
                                    assetResponse.reasonPhrase ?: "OK",
                                    headers,
                                    modifiedHtml.byteInputStream(Charsets.UTF_8)
                                )
                            } catch (e: Exception) {
                                Log.e(TAG, "Failed to inject cleartext script into HTML: ${e.message}", e)
                                try {
                                    val cleanPath = "www/" + path.substringAfter("/assets/").removePrefix("www/").removePrefix("/").ifBlank { "index.html" }
                                    val assetStream = assets.open(cleanPath)
                                    return WebResourceResponse("text/html", "UTF-8", 200, "OK", null, assetStream)
                                } catch (_: Exception) {}
                            }
                        }
                        return assetResponse
                    }
                }

                val path = url.path ?: ""
                val host = url.host?.lowercase() ?: ""
                val isCleartextProxy = host == "appassets.androidplatform.net" && path.startsWith("/__cleartext_proxy__")
                val isDirectHttp = url.scheme?.equals("http", ignoreCase = true) == true && host != "appassets.androidplatform.net"

                if (isCleartextProxy || isDirectHttp) {
                    val targetUrl = if (isCleartextProxy) {
                        url.getQueryParameter("url")
                    } else {
                        url.toString()
                    }

                    if (!targetUrl.isNullOrBlank()) {
                        val proxyResponse = fetchProxyResource(targetUrl, request)
                        if (proxyResponse != null) return proxyResponse
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customVideoView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customVideoView = view
                customViewCallback = callback

                val rootLayout: FrameLayout = findViewById(R.id.root_layout)
                val contentContainer: View = findViewById(R.id.main_content_container)
                contentContainer.visibility = View.INVISIBLE
                if (view != null) {
                    view.layoutParams = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                    rootLayout.addView(view)
                }
                val insetsController = WindowInsetsControllerCompat(window, window.decorView)
                insetsController.hide(WindowInsetsCompat.Type.systemBars())
                insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (isUrlMode && displayConfig.loadingIndicator) {
                    if (newProgress < 100) {
                        progressBar.visibility = ProgressBar.VISIBLE
                        progressBar.progress = newProgress
                    } else {
                        progressBar.visibility = ProgressBar.GONE
                    }
                }
            }

            override fun onConsoleMessage(message: ConsoleMessage?): Boolean {
                message?.let {
                    Log.d(TAG, "JS console [${it.messageLevel()}] ${it.sourceId()}:${it.lineNumber()} - ${it.message()}")
                }
                return super.onConsoleMessage(message)
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                if (settings.geolocationEnabled) {
                    callback?.invoke(origin, true, false)
                } else {
                    callback?.invoke(origin, false, false)
                }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                runOnUiThread {
                    if (request == null) return@runOnUiThread
                    val neededPermissions = mutableListOf<String>()
                    request.resources.forEach { resource ->
                        if (resource == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
                            neededPermissions.add(Manifest.permission.CAMERA)
                        } else if (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
                            neededPermissions.add(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                    val missing = neededPermissions.filter {
                        ContextCompat.checkSelfPermission(this@WebViewActivity, it) != PackageManager.PERMISSION_GRANTED
                    }
                    if (missing.isNotEmpty()) {
                        pendingWebPermissionRequest = request
                        multiplePermissionsLauncher.launch(missing.toTypedArray())
                    } else {
                        request.grant(request.resources)
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@WebViewActivity.filePathCallback?.onReceiveValue(null)
                this@WebViewActivity.filePathCallback = filePathCallback

                val rawTypes = fileChooserParams?.acceptTypes?.filter { it.isNotBlank() } ?: emptyList()
                val mimeTypes = mutableListOf<String>()
                rawTypes.forEach { raw ->
                    val clean = raw.trim().lowercase(Locale.ROOT)
                    if (clean.startsWith(".")) {
                        val ext = clean.removePrefix(".")
                        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                        if (mime != null) {
                            mimeTypes.add(mime)
                        } else if (ext == "json") {
                            mimeTypes.add("application/json")
                        } else {
                            mimeTypes.add("*/*")
                        }
                    } else if (clean.contains("/")) {
                        mimeTypes.add(clean)
                    }
                }

                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    if (mimeTypes.isEmpty()) {
                        type = "*/*"
                    } else if (mimeTypes.size == 1) {
                        type = mimeTypes[0]
                    } else {
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toTypedArray())
                    }
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                }
                try {
                    fileChooserLauncher.launch(Intent.createChooser(intent, "Choose file"))
                    return true
                } catch (e: Exception) {
                    this@WebViewActivity.filePathCallback?.onReceiveValue(null)
                    this@WebViewActivity.filePathCallback = null
                    return false
                }
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
            if (url.isNullOrBlank()) return@setDownloadListener
            val trimmedUrl = url.trim()
            if (trimmedUrl.startsWith("blob:", ignoreCase = true)) {
                // Blob URLs are handled by the injected click interceptor that calls AndroidAPI.downloadBlobUrl(...)
                return@setDownloadListener
            }
            if (trimmedUrl.startsWith("data:", ignoreCase = true)) {
                downloadDataUri(trimmedUrl, contentDisposition, mimetype)
                return@setDownloadListener
            }
            if (!trimmedUrl.startsWith("http://", ignoreCase = true) && !trimmedUrl.startsWith("https://", ignoreCase = true)) {
                Log.w(TAG, "DownloadManager only supports HTTP/HTTPS, skipping scheme: $trimmedUrl")
                return@setDownloadListener
            }
            try {
                val guessedName = URLUtil.guessFileName(trimmedUrl, contentDisposition, mimetype)
                val request = DownloadManager.Request(Uri.parse(trimmedUrl)).apply {
                    setMimeType(mimetype)
                    addRequestHeader("User-Agent", userAgent)
                    setDescription("Downloading file…")
                    setTitle(guessedName)
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, guessedName)
                }
                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this, R.string.download_started, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Log.e(TAG, "DownloadManager enqueue failed", e)
            }
        }

        if (displayConfig.hasSplash) {
            try {
                splashView.setImageDrawable(null)
                val inputStream = assets.open("www/splash.png")
                val drawable = android.graphics.drawable.Drawable.createFromStream(inputStream, null)
                splashView.setImageDrawable(drawable)
                splashView.visibility = ImageView.VISIBLE
                Handler(Looper.getMainLooper()).postDelayed({
                    splashView.visibility = ImageView.GONE
                }, 2000)
            } catch (e: Exception) {
                splashView.visibility = ImageView.GONE
            }
        }

        val targetUrl = when (displayConfig.mode) {
            "url" -> displayConfig.url
            else -> "https://appassets.androidplatform.net/assets/www/index.html"
        }
        if (isUrlMode && displayConfig.noInternetDialog && !isNetworkConnected()) {
            showNoInternetDialog()
        }
        webView.post {
            webView.loadUrl(targetUrl)
        }

        launchDeepLink = intent?.data?.toString()

        requestLaunchPermissions(displayConfig.permissions)
    }

    private fun isNetworkConnected(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val network = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(network) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                val netInfo = cm.activeNetworkInfo
                @Suppress("DEPRECATION")
                netInfo != null && netInfo.isConnected
            }
        } catch (_: Exception) {
            true
        }
    }

    private fun showNoInternetDialog() {
        if (noInternetDialog?.isShowing == true || isFinishing || isDestroyed) return
        noInternetDialog = IosDialogHelper.showNoInternet(this) {
            if (isNetworkConnected()) {
                noInternetDialog?.dismiss()
                noInternetDialog = null
                lastPageLoadFailed = false
                val targetUrl = when (displayConfig.mode) {
                    "url" -> displayConfig.url
                    else -> "https://appassets.androidplatform.net/assets/www/index.html"
                }
                webView.loadUrl(targetUrl)
            } else {
                Toast.makeText(this, R.string.ios_dialog_no_internet_title, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun hideCustomView() {
        val view = customVideoView ?: return
        val rootLayout: FrameLayout = findViewById(R.id.root_layout)
        val contentContainer: View = findViewById(R.id.main_content_container)
        rootLayout.removeView(view)
        contentContainer.visibility = View.VISIBLE
        customVideoView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        if (displayConfig.showHeader) {
            val insetsController = WindowInsetsControllerCompat(window, window.decorView)
            insetsController.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun fetchProxyResource(targetUrl: String, request: WebResourceRequest): WebResourceResponse? {
        return try {
            val method = request.method ?: "GET"

            // Handle CORS preflight OPTIONS requests immediately
            if (method.equals("OPTIONS", ignoreCase = true)) {
                val headers = mutableMapOf(
                    "Access-Control-Allow-Origin" to "*",
                    "Access-Control-Allow-Methods" to "GET, POST, PUT, DELETE, HEAD, OPTIONS, PATCH",
                    "Access-Control-Allow-Headers" to "*",
                    "Access-Control-Allow-Credentials" to "true",
                    "Access-Control-Max-Age" to "86400"
                )
                return WebResourceResponse("text/plain", "UTF-8", 200, "OK", headers, "".byteInputStream())
            }

            var currentUrl = targetUrl
            var redirects = 0
            var conn: java.net.HttpURLConnection

            // Follow cross-protocol redirects manually (HTTP -> HTTPS or vice versa)
            while (true) {
                val urlObj = java.net.URL(currentUrl)
                conn = urlObj.openConnection() as java.net.HttpURLConnection
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 15000
                conn.readTimeout = 60000
                conn.requestMethod = method

                request.requestHeaders?.forEach { (key, value) ->
                    val lowerKey = key.lowercase()
                    // Filter out headers that cause issues when proxying
                    if (lowerKey != "host" &&
                        lowerKey != "accept-encoding" &&
                        !lowerKey.startsWith("sec-fetch-") &&
                        !(lowerKey == "origin" && value.contains("appassets.androidplatform.net")) &&
                        !(lowerKey == "referer" && value.contains("appassets.androidplatform.net"))
                    ) {
                        try { conn.setRequestProperty(key, value) } catch (_: Throwable) {}
                    }
                }
                val ua = cachedUserAgent.ifBlank { "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36" }
                if (conn.getRequestProperty("User-Agent").isNullOrBlank()) {
                    try { conn.setRequestProperty("User-Agent", ua) } catch (_: Throwable) {}
                }

                conn.connect()
                val code = conn.responseCode
                if ((code in 301..303 || code == 307 || code == 308) && redirects < 5) {
                    val location = conn.getHeaderField("Location")
                    if (!location.isNullOrBlank()) {
                        currentUrl = java.net.URL(urlObj, location).toString()
                        redirects++
                        conn.disconnect()
                        continue
                    }
                }
                break
            }

            val statusCode = conn.responseCode
            val statusMessage = conn.responseMessage?.takeIf { it.isNotBlank() } ?: when (statusCode) {
                200 -> "OK"
                206 -> "Partial Content"
                else -> "OK"
            }
            val rawContentType = conn.contentType ?: "application/octet-stream"
            val mimeType = rawContentType.substringBefore(";").trim()

            // CRITICAL: Hop-by-hop headers MUST NOT be forwarded to Chromium WebResourceResponse!
            // Forwarding Transfer-Encoding: chunked or Connection causes ERR_INVALID_CHUNKED_ENCODING.
            val hopByHopHeaders = setOf(
                "connection",
                "keep-alive",
                "transfer-encoding",
                "te",
                "trailer",
                "upgrade",
                "proxy-authenticate",
                "proxy-authorization"
            )

            val responseHeaders = mutableMapOf<String, String>()
            conn.headerFields?.forEach { (key, values) ->
                if (key != null && !hopByHopHeaders.contains(key.lowercase()) && values.isNotEmpty()) {
                    responseHeaders[key] = values.joinToString(", ")
                }
            }

            val contentEncoding = conn.contentEncoding?.lowercase() ?: ""
            val rawStream = if (statusCode >= 400) conn.errorStream ?: conn.inputStream else conn.inputStream

            // Handle decompression if compressed
            val inputStream = when {
                contentEncoding.contains("gzip") && rawStream != null -> java.util.zip.GZIPInputStream(rawStream)
                contentEncoding.contains("deflate") && rawStream != null -> java.util.zip.InflaterInputStream(rawStream)
                else -> rawStream
            }

            if (contentEncoding.contains("gzip") || contentEncoding.contains("deflate")) {
                val keysToRemove = responseHeaders.keys.filter {
                    it.equals("Content-Encoding", ignoreCase = true) || it.equals("Content-Length", ignoreCase = true)
                }
                keysToRemove.forEach { responseHeaders.remove(it) }
            }

            // CRITICAL: IPTV / HLS .m3u8 Playlist Rewriting
            // If the response is an M3U8 playlist, rewrite relative/HTTP URIs so every .ts segment goes through the proxy!
            val isM3u8 = mimeType.contains("mpegurl", ignoreCase = true) ||
                    targetUrl.substringBefore("?").endsWith(".m3u8", ignoreCase = true)

            if (isM3u8 && inputStream != null) {
                val playlistText = inputStream.bufferedReader().use { it.readText() }
                val baseUrl = java.net.URL(currentUrl)
                val rewrittenLines = playlistText.lineSequence().map { line ->
                    val trimmed = line.trim()
                    if (trimmed.isEmpty()) {
                        line
                    } else if (trimmed.startsWith("#")) {
                        if (trimmed.contains("URI=\"")) {
                            trimmed.replace(Regex("URI=\"([^\"]+)\"")) { matchResult ->
                                val uriVal = matchResult.groupValues[1]
                                val resolvedUri = try { java.net.URL(baseUrl, uriVal).toString() } catch (_: Exception) { uriVal }
                                val proxied = if (resolvedUri.startsWith("http://")) {
                                    CLEARTEXT_PROXY_PREFIX + java.net.URLEncoder.encode(resolvedUri, "UTF-8")
                                } else resolvedUri
                                "URI=\"$proxied\""
                            }
                        } else {
                            line
                        }
                    } else {
                        val resolvedUri = try { java.net.URL(baseUrl, trimmed).toString() } catch (_: Exception) { trimmed }
                        if (resolvedUri.startsWith("http://")) {
                            CLEARTEXT_PROXY_PREFIX + java.net.URLEncoder.encode(resolvedUri, "UTF-8")
                        } else {
                            resolvedUri
                        }
                    }
                }.joinToString("\n")

                val rewrittenBytes = rewrittenLines.toByteArray(Charsets.UTF_8)
                responseHeaders["Content-Length"] = rewrittenBytes.size.toString()
                responseHeaders["Access-Control-Allow-Origin"] = "*"
                responseHeaders["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, HEAD, OPTIONS, PATCH"
                responseHeaders["Access-Control-Allow-Headers"] = "*"
                responseHeaders["Access-Control-Allow-Credentials"] = "true"
                responseHeaders["Access-Control-Expose-Headers"] = "Content-Length, Content-Range, Accept-Ranges, Content-Type"
                responseHeaders["Accept-Ranges"] = "bytes"
                return WebResourceResponse(
                    "application/vnd.apple.mpegurl",
                    "UTF-8",
                    statusCode,
                    statusMessage,
                    responseHeaders,
                    rewrittenBytes.inputStream()
                )
            }

            // CRITICAL: Binary content (video, audio, images, TS chunks, streams) MUST have encoding = null!
            // Passing "UTF-8" causes Chromium media pipeline to fail with MEDIA_ERR_SRC_NOT_SUPPORTED!
            val isBinary = mimeType.startsWith("video/", ignoreCase = true) ||
                    mimeType.startsWith("audio/", ignoreCase = true) ||
                    mimeType.startsWith("image/", ignoreCase = true) ||
                    mimeType.equals("application/octet-stream", ignoreCase = true) ||
                    mimeType.equals("application/pdf", ignoreCase = true) ||
                    mimeType.equals("application/wasm", ignoreCase = true) ||
                    targetUrl.substringBefore("?").endsWith(".ts", ignoreCase = true) ||
                    targetUrl.substringBefore("?").endsWith(".mp4", ignoreCase = true)

            val encoding = if (isBinary) {
                null
            } else if (rawContentType.contains("charset=", ignoreCase = true)) {
                rawContentType.substringAfter("charset=", "").substringBefore(";").trim().takeIf { it.isNotBlank() }
            } else {
                null
            }

            responseHeaders["Access-Control-Allow-Origin"] = "*"
            responseHeaders["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, HEAD, OPTIONS, PATCH"
            responseHeaders["Access-Control-Allow-Headers"] = "*"
            responseHeaders["Access-Control-Allow-Credentials"] = "true"
            responseHeaders["Access-Control-Expose-Headers"] = "Content-Length, Content-Range, Accept-Ranges, Content-Type"
            responseHeaders["Accept-Ranges"] = "bytes"

            WebResourceResponse(mimeType, encoding, statusCode, statusMessage, responseHeaders, inputStream)
        } catch (e: Exception) {
            Log.e(TAG, "fetchProxyResource failed for $targetUrl: ${e.message}", e)
            null
        }
    }

    private fun emitDeepLink() {
        val link = launchDeepLink ?: return
        val script = "window.onDeepLink && window.onDeepLink(${JSONObject.quote(link)})"
        webView.evaluateJavascript(script, null)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        launchDeepLink = intent.data?.toString()
        if (::webView.isInitialized) {
            emitDeepLink()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) {
            webView.onResume()
        }
        if (::adMobBridge.isInitialized) {
            adMobBridge.onResume()
        }
    }

    override fun onPause() {
        if (::adMobBridge.isInitialized) {
            adMobBridge.onPause()
        }
        super.onPause()
        if (::webView.isInitialized) {
            webView.onPause()
        }
        try {
            CookieManager.getInstance().flush()
        } catch (_: Exception) {}
        androidApi.stopAllSensors()
        androidApi.stopLocationUpdates()
    }

    override fun onDestroy() {
        super.onDestroy()
        pageLoadHandler.removeCallbacks(pageLoadTimeoutRunnable)
        cameraExecutor.shutdown()
        if (::adMobBridge.isInitialized) adMobBridge.destroy()
        try {
            CookieManager.getInstance().flush()
        } catch (_: Exception) {}
    }

    fun requestPermission(permission: String, callbackId: String) {
        pendingPermissionCallbackId = callbackId
        pendingPermission = permission
        permissionLauncher.launch(permission)
    }

    fun requestPermissions(permissions: Array<String>, callbackId: String) {
        pendingPermissionsCallbackId = callbackId
        multiplePermissionsLauncher.launch(permissions)
    }

    fun capturePhoto(callbackId: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingCameraCallbackId = callbackId
            pendingPermission = Manifest.permission.CAMERA
            permissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        launchCameraIntent(callbackId)
    }

    fun launchCameraIntent(callbackId: String) {
        try {
            val file = File(cacheDir, "capture_${System.currentTimeMillis()}.jpg").apply { parentFile?.mkdirs() }
            pendingPhotoFile = file
            pendingCameraCallbackId = callbackId
            val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
            takePictureLauncher.launch(uri)
        } catch (e: Exception) {
            Log.e(TAG, "capturePhoto launch failed", e)
            pendingCameraCallbackId = null
            pendingPhotoFile = null
            androidApi.onCameraResult(callbackId, false, null)
        }
    }

    fun startCameraPreview() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return
        }
        previewView.visibility = View.VISIBLE
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder()
                    .build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview)
            } catch (_: Exception) {
                previewView.visibility = View.GONE
            }
        }, ContextCompat.getMainExecutor(this))
    }

    fun stopCameraPreview() {
        previewView.visibility = View.GONE
        try {
            val cameraProvider = ProcessCameraProvider.getInstance(this).get()
            cameraProvider.unbindAll()
        } catch (_: Exception) {
        }
    }

    fun pickFile(mimeType: String, callbackId: String) {
        pendingFileCallbackId = callbackId
        pickFileLauncher.launch(arrayOf(mimeType))
    }

    fun createFile(fileName: String, mimeType: String, content: String, callbackId: String) {
        pendingWriteCallbackId = callbackId
        pendingWriteContent = content
        createDocumentLauncher.launch(fileName)
    }

    private fun requestLaunchPermissions(permissions: List<String>) {
        if (permissions.isEmpty()) return
        val runtimePerms = permissions.mapNotNull { toRuntimePermission(it) }.distinct()
        if (runtimePerms.isEmpty()) return
        launchPermissionsLauncher.launch(runtimePerms.toTypedArray())
    }

    private fun toRuntimePermission(permission: String): String? {
        return when (permission) {
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE -> permission
            Manifest.permission.POST_NOTIFICATIONS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) permission else null
            }
            Manifest.permission.ACTIVITY_RECOGNITION -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) permission else null
            }
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE -> {
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) permission else null
            }
            else -> null
        }
    }

    @Suppress("DEPRECATION")
    private fun applyPrimaryColor(colorString: String, showActionBar: Boolean) {
        try {
            val color = android.graphics.Color.parseColor(colorString)
            if (showActionBar) {
                toolbar?.setBackgroundColor(color)
                val isLight = androidx.core.graphics.ColorUtils.calculateLuminance(color) > 0.5
                toolbarTitle?.setTextColor(if (isLight) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        } catch (e: IllegalArgumentException) {
            // ignore invalid color
        }
    }

    private fun getActionBarHeight(): Int {
        return getTopActionBarHeight()
    }

    fun getSystemBarInsets(): androidx.core.graphics.Insets {
        if (!::webView.isInitialized) return androidx.core.graphics.Insets.NONE
        val rootInsets = ViewCompat.getRootWindowInsets(webView) ?: return androidx.core.graphics.Insets.NONE
        return rootInsets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        )
    }

    fun getTopActionBarHeight(): Int {
        if (!displayConfig.showActionBar) return 0
        val tb = toolbar ?: return 0
        if (tb.visibility != View.VISIBLE) return 0
        val measured = tb.height
        if (measured > 0) return measured
        val typedValue = android.util.TypedValue()
        val baseHeight = if (theme.resolveAttribute(android.R.attr.actionBarSize, typedValue, true)) {
            android.util.TypedValue.complexToDimensionPixelSize(typedValue.data, resources.displayMetrics)
        } else {
            (56 * resources.displayMetrics.density).toInt()
        }
        val statusBar = if (displayConfig.showHeader) {
            val rootInsets = ViewCompat.getRootWindowInsets(tb)
            rootInsets?.getInsets(WindowInsetsCompat.Type.statusBars())?.top ?: 0
        } else 0
        return baseHeight + statusBar
    }

    private fun readDisplayConfig(): DisplayConfig {
        return try {
            val json = readConfigJson()
            val obj = JSONObject(json)
            DisplayConfig(
                mode = obj.optString("mode", "local"),
                url = obj.optString("url", ""),
                showHeader = obj.optBoolean("showHeader", true),
                showActionBar = obj.optBoolean("showActionBar", true),
                keepScreenOn = obj.optBoolean("keepScreenOn", false),
                showCameraCutout = obj.optBoolean("showCameraCutout", false),
                desktopMode = obj.optBoolean("desktopMode", false),
                pullToRefresh = obj.optBoolean("pullToRefresh", true),
                noInternetDialog = obj.optBoolean("noInternetDialog", true),
                loadingIndicator = obj.optBoolean("loadingIndicator", false),
                backHistoryNavigation = obj.optBoolean("backHistoryNavigation", true),
                exitConfirmationDialog = obj.optBoolean("exitConfirmationDialog", false),
                orientation = obj.optString("orientation", "portrait"),
                primaryColor = obj.optString("primaryColor", "#00E5CC"),
                hasSplash = obj.optBoolean("hasSplash", false),
                showWatermark = obj.optBoolean("showWatermark", false),
                isPro = obj.optBoolean("isPro", false),
                permissions = parsePermissions(obj.optJSONArray("permissions")),
                webViewSettings = parseWebViewSettings(obj.optJSONObject("webViewSettings")),
                admobEnabled = obj.optBoolean("admobEnabled", false),
                admobAppId = obj.optString("admobAppId", ""),
                admobBannerUnitId = obj.optString("admobBannerUnitId", ""),
                admobInterstitialUnitId = obj.optString("admobInterstitialUnitId", ""),
                admobRewardedUnitId = obj.optString("admobRewardedUnitId", ""),
                admobBannerPosition = obj.optString("admobBannerPosition", "bottom"),
                admobShowBannerOnStart = obj.optBoolean("admobShowBannerOnStart", false),
                admobTestDeviceIds = parseTestDeviceIds(obj.optJSONArray("admobTestDeviceIds")),
                admobAutoLoadInterstitial = obj.optBoolean("admobAutoLoadInterstitial", false),
                admobAutoLoadRewarded = obj.optBoolean("admobAutoLoadRewarded", false),
                admobUseTestAds = obj.optBoolean("admobUseTestAds", false),
                admobBannerEnabled = obj.optBoolean("admobBannerEnabled", false),
                admobInterstitialEnabled = obj.optBoolean("admobInterstitialEnabled", false),
                admobRewardedEnabled = obj.optBoolean("admobRewardedEnabled", false),
                admobInterstitialIntervalSeconds = obj.optInt("admobInterstitialIntervalSeconds", 0),
                admobInterstitialPageCount = obj.optInt("admobInterstitialPageCount", 0)
            )
        } catch (e: Exception) {
            DisplayConfig()
        }
    }

    private fun readConfigJson(): String {
        // Try the encrypted runtime config first.
        return try {
            val plain = assets.open("www/runtime.cache").use { ConfigCrypto.decryptConfig(it) }
            String(plain, Charsets.UTF_8)
        } catch (_: Exception) {
            // Fallback for old/unsigned/debug builds that still ship plaintext config.json.
            assets.open("www/config.json").bufferedReader().use { it.readText() }
        }
    }

    private fun parseWebViewSettings(obj: JSONObject?): WebViewSettings {
        if (obj == null) return WebViewSettings()
        return WebViewSettings(
            javaScriptEnabled = obj.optBoolean("javaScriptEnabled", true),
            domStorageEnabled = obj.optBoolean("domStorageEnabled", true),
            allowFileAccess = obj.optBoolean("allowFileAccess", false),
            allowContentAccess = obj.optBoolean("allowContentAccess", false),
            allowUniversalAccessFromFileURLs = obj.optBoolean("allowUniversalAccessFromFileURLs", true),
            allowFileAccessFromFileURLs = obj.optBoolean("allowFileAccessFromFileURLs", true),
            builtInZoomControls = obj.optBoolean("builtInZoomControls", true),
            displayZoomControls = obj.optBoolean("displayZoomControls", false),
            useWideViewPort = obj.optBoolean("useWideViewPort", true),
            loadWithOverviewMode = obj.optBoolean("loadWithOverviewMode", true),
            cacheMode = obj.optInt("cacheMode", WebSettings.LOAD_DEFAULT),
            mixedContentMode = obj.optInt("mixedContentMode", WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE),
            userAgent = obj.optString("userAgent").takeIf { it.isNotBlank() },
            textZoom = obj.optInt("textZoom", 100),
            geolocationEnabled = obj.optBoolean("geolocationEnabled", false)
        )
    }

    private fun parsePermissions(array: org.json.JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { array.optString(it) }.filter { it.isNotBlank() }
    }

    private fun parseTestDeviceIds(array: org.json.JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { array.optString(it) }.filter { it.isNotBlank() }
    }

    private fun readUriContent(uri: Uri): String? {
        return when (uri.scheme) {
            "content" -> {
                contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = input.readBytes()
                    android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                }
            }
            "file" -> {
                File(uri.path ?: return null).readBytes().let {
                    android.util.Base64.encodeToString(it, android.util.Base64.NO_WRAP)
                }
            }
            else -> null
        }
    }

    fun downloadDataUri(url: String, contentDisposition: String? = null, mimeType: String? = null) {
        Thread {
            try {
                val commaIndex = url.indexOf(',')
                if (commaIndex == -1) return@Thread
                val metadata = url.substring(0, commaIndex)
                val rawData = url.substring(commaIndex + 1)
                val isBase64 = metadata.contains(";base64", ignoreCase = true)
                val explicitMime = metadata.removePrefix("data:").substringBefore(';').trim().takeIf { it.isNotBlank() }
                    ?: mimeType?.takeIf { it.isNotBlank() }
                    ?: "application/octet-stream"

                val bytes: ByteArray = if (isBase64) {
                    android.util.Base64.decode(rawData, android.util.Base64.DEFAULT)
                } else {
                    java.net.URLDecoder.decode(rawData, "UTF-8").toByteArray(Charsets.UTF_8)
                }
                if (bytes.isEmpty()) return@Thread

                val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(explicitMime) ?: when {
                    explicitMime.contains("json") -> "json"
                    explicitMime.contains("csv") -> "csv"
                    explicitMime.contains("sheet") || explicitMime.contains("excel") -> "xlsx"
                    explicitMime.contains("text") -> "txt"
                    else -> "bin"
                }
                val explicitName = contentDisposition?.let { cd ->
                    if (cd.contains("filename=", ignoreCase = true)) {
                        cd.substringAfter("filename=").trim('"', ' ', ';')
                    } else if (!cd.startsWith("attachment", ignoreCase = true) && cd.contains(".")) {
                        cd.trim('"', ' ')
                    } else {
                        null
                    }
                }
                val guessedName = explicitName ?: URLUtil.guessFileName(url, contentDisposition, explicitMime)
                val fileName = if (!explicitName.isNullOrBlank()) {
                    explicitName
                } else if (guessedName.isNotBlank() && guessedName != "downloadfile.bin" && !guessedName.contains(";base64")) {
                    guessedName
                } else {
                    "export_${System.currentTimeMillis()}.$ext"
                }

                saveBytesToDownloads(bytes, fileName, explicitMime)
            } catch (e: Exception) {
                Log.e(TAG, "Data URI download failed", e)
            }
        }.start()
    }

    fun saveBytesToDownloads(bytes: ByteArray, fileName: String, mimeType: String) {
        try {
            val resolver = contentResolver
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Files.getContentUri("external")
            }
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
            }
            val uri = resolver.insert(collection, contentValues)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out ->
                    out.write(bytes)
                }
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.download_completed, fileName), Toast.LENGTH_SHORT).show()
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                downloadsDir.mkdirs()
                val target = File(downloadsDir, fileName)
                target.writeBytes(bytes)
                runOnUiThread {
                    Toast.makeText(this, getString(R.string.download_completed, fileName), Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save file to downloads", e)
            runOnUiThread {
                Toast.makeText(this, getString(R.string.download_failed, e.message ?: ""), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun injectCleartextInterceptor() {
        if (!::webView.isInitialized) return
        runOnUiThread {
            webView.evaluateJavascript(CLEARTEXT_INTERCEPTOR_SCRIPT, null)
        }
    }

    private fun injectBlobDownloadInterceptor() {
        val script = """
            (function() {
                if (window.__htmlToApkDownloadInterceptor) return;
                window.__htmlToApkDownloadInterceptor = true;

                function handleDownload(href, filename, mimeType) {
                    if (!href) return;
                    if (href.startsWith('blob:') || href.startsWith('data:')) {
                        if (typeof AndroidAPI !== 'undefined' && AndroidAPI.downloadBlobUrl) {
                            AndroidAPI.downloadBlobUrl(href, filename || 'download', mimeType || 'application/octet-stream');
                        }
                    }
                }

                document.addEventListener('click', function(e) {
                    const a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
                    if (!a || typeof a.href !== 'string') return;
                    if (a.href.startsWith('blob:') || a.href.startsWith('data:')) {
                        e.preventDefault();
                        e.stopPropagation();
                        handleDownload(a.href, a.download || a.getAttribute('download') || 'download', a.type || '');
                    }
                }, true);

                try {
                    const origClick = HTMLAnchorElement.prototype.click;
                    HTMLAnchorElement.prototype.click = function() {
                        const downloadAttr = this.getAttribute('download');
                        if (downloadAttr !== null && typeof this.href === 'string' && (this.href.startsWith('blob:') || this.href.startsWith('data:'))) {
                            handleDownload(this.href, downloadAttr || 'download', this.type || '');
                            return;
                        }
                        return origClick.apply(this, arguments);
                    };
                } catch (_) {}
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    private fun onPageLoadFailed(message: String) {
        pageLoadFinished = true
        pageLoadHandler.removeCallbacks(pageLoadTimeoutRunnable)
        progressBar.visibility = ProgressBar.GONE
        splashView.visibility = ImageView.GONE
        Log.e(TAG, message)
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
    }

    private fun onPageLoadTimedOut() {
        if (pageLoadFinished) return
        lastPageLoadFailed = true
        if (displayConfig.mode == "url" && displayConfig.noInternetDialog) {
            showNoInternetDialog()
        } else {
            onPageLoadFailed(getString(R.string.page_load_timeout))
        }
    }

    /**
     * Decide whether a URL should be loaded inside the WebView or handed off
     * to an external app / the Play Store. This prevents errors such as
     * net::ERR_UNKNOWN_URL_SCHEME for intent:// links.
     */
    private fun handleExternalNavigation(uri: Uri?): Boolean {
        if (uri == null) return false
        val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return false

        return when {
            scheme == "http" || scheme == "https" -> {
                val host = uri.host?.lowercase(Locale.ROOT) ?: return false
                when {
                    host.contains("play.google.com") || host.contains("market.android.com") -> {
                        launchExternalApp(uri, "com.android.vending")
                    }
                    else -> false
                }
            }
            scheme == "intent" -> handleIntentUrl(uri.toString())
            scheme == "tel" -> launchExternalApp(Intent(Intent.ACTION_DIAL, uri))
            scheme == "mailto" -> launchExternalApp(Intent(Intent.ACTION_SENDTO, uri))
            scheme == "market" -> launchExternalApp(uri, "com.android.vending")
            else -> launchExternalApp(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun handleIntentUrl(urlString: String): Boolean {
        return try {
            val intent = Intent.parseUri(urlString, Intent.URI_INTENT_SCHEME)
            val packageName = intent.`package`
            if (packageName != null && isPackageInstalled(packageName)) {
                launchExternalApp(intent)
            } else {
                val fallback = intent.getStringExtra("browser_fallback_url")
                    ?: intent.getStringExtra("S.browser_fallback_url")
                if (!fallback.isNullOrBlank()) {
                    launchExternalApp(Uri.parse(fallback))
                } else if (packageName != null) {
                    launchExternalApp(
                        Uri.parse("https://play.google.com/store/apps/details?id=$packageName"),
                        "com.android.vending"
                    )
                } else {
                    false
                }
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun launchExternalApp(uri: Uri, preferredPackage: String? = null): Boolean {
        return launchExternalApp(Intent(Intent.ACTION_VIEW, uri), preferredPackage)
    }

    private fun launchExternalApp(intent: Intent, preferredPackage: String? = null): Boolean {
        return try {
            if (!preferredPackage.isNullOrBlank() && isPackageInstalled(preferredPackage)) {
                intent.setPackage(preferredPackage)
            }
            startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun isPackageInstalled(packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                packageManager.getPackageInfo(packageName, 0)
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}
