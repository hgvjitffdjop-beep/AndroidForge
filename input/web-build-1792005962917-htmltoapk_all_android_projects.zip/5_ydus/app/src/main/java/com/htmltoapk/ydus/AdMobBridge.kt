package com.htmltoapk.ydus

import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import org.json.JSONObject

object AdMobTestIds {
    const val APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val BANNER = "ca-app-pub-3940256099942544/6300978111"
    const val INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
    const val REWARDED = "ca-app-pub-3940256099942544/5224354917"
}

class AdMobBridge(
    private val activity: WebViewActivity,
    private val config: WebViewActivity.DisplayConfig,
    private val emit: (String, JSONObject) -> Unit
) {

    private val mainHandler = Handler(Looper.getMainLooper())

    private var bannerAdView: AdView? = null
    private var bannerPosition: String = "bottom"

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null

    private var pageLoadCounter = 0
    private var lastInterstitialShowTime = 0L
    private val autoShowRunnable = Runnable { autoShowInterstitialTick() }

    val isEnabled: Boolean
        get() = config.admobEnabled && (config.admobUseTestAds || config.admobAppId.isNotBlank())

    val bannerId: String?
        get() = when {
            !config.admobEnabled -> null
            config.admobUseTestAds -> AdMobTestIds.BANNER
            config.admobBannerUnitId.isNotBlank() -> config.admobBannerUnitId.trim()
            config.admobBannerEnabled -> AdMobTestIds.BANNER
            else -> null
        }

    val interstitialId: String?
        get() = when {
            !config.admobEnabled -> null
            config.admobUseTestAds -> AdMobTestIds.INTERSTITIAL
            config.admobInterstitialUnitId.isNotBlank() -> config.admobInterstitialUnitId.trim()
            config.admobInterstitialEnabled -> AdMobTestIds.INTERSTITIAL
            else -> null
        }

    val rewardedId: String?
        get() = when {
            !config.admobEnabled -> null
            config.admobUseTestAds -> AdMobTestIds.REWARDED
            config.admobRewardedUnitId.isNotBlank() -> config.admobRewardedUnitId.trim()
            config.admobRewardedEnabled -> AdMobTestIds.REWARDED
            else -> null
        }

    fun isRewardedLoaded(): Boolean = rewardedAd != null
    fun isInterstitialLoaded(): Boolean = interstitialAd != null
    fun isBannerLoaded(): Boolean = bannerAdView != null

    init {
        if (isEnabled) {
            val testDevices = config.admobTestDeviceIds
            if (testDevices.isNotEmpty()) {
                MobileAds.setRequestConfiguration(
                    RequestConfiguration.Builder()
                        .setTestDeviceIds(testDevices)
                        .build()
                )
            }
            MobileAds.initialize(activity) { status ->
                emit("admobInitialized", JSONObject().apply {
                    put("status", status.toString())
                })
            }

            bannerId?.let {
                loadBanner(it, config.admobBannerPosition)
                if (config.admobShowBannerOnStart) showBanner()
            }
            interstitialId?.let {
                loadInterstitial(it)
                scheduleAutoShowInterstitial()
            }
            rewardedId?.let {
                loadRewarded(it)
            }
        }
    }

    private fun runOnUiThread(action: () -> Unit) {
        mainHandler.post(action)
    }

    private fun buildAdRequest(): AdRequest {
        return AdRequest.Builder().build()
    }

    // --- Banner ---

    fun loadBanner(adUnitId: String, position: String) {
        if (!isEnabled) {
            emitAdError("adFailedToLoad", "AdMob not configured", "banner")
            return
        }
        runOnUiThread {
            removeBanner()
            bannerPosition = when {
                position == "top" -> "top"
                position == "bottom" -> "bottom"
                config.admobBannerPosition == "top" -> "top"
                else -> "bottom"
            }
            val adView = AdView(activity).apply {
                this.adUnitId = adUnitId
                setAdSize(AdSize.BANNER)
            }
            bannerAdView = adView
            adView.adListener = object : AdListener() {
                override fun onAdLoaded() {
                    emit("adLoaded", adEventJson("banner", adUnitId))
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    emit("adFailedToLoad", adEventJson("banner", adUnitId).apply {
                        put("code", error.code)
                        put("message", error.message)
                    })
                }
            }
            adView.loadAd(buildAdRequest())
        }
    }

    fun showBanner() {
        if (!isEnabled) {
            emitAdError("adFailedToLoad", "AdMob is disabled in Project Settings (Step 8: Ads). Please enable AdMob to display ads.", "banner")
            return
        }
        runOnUiThread {
            val adView = bannerAdView ?: run {
                bannerId?.let { id ->
                    loadBanner(id, bannerPosition)
                } ?: emitAdError("adFailedToLoad", "Banner ad is not enabled in Project Settings.", "banner")
                return@runOnUiThread
            }
            val root = activity.findViewById<FrameLayout>(android.R.id.content)
                ?: activity.findViewById<View>(R.id.webview)?.parent as? FrameLayout
            root?.let { attachBanner(it, adView) }
            adView.visibility = View.VISIBLE
            activity.updateBannerPadding(true, bannerPosition == "top")
        }
    }

    fun hideBanner() {
        runOnUiThread {
            bannerAdView?.visibility = View.GONE
            activity.updateBannerPadding(false, bannerPosition == "top")
        }
    }

    private fun removeBanner() {
        bannerAdView?.let { old ->
            old.parent?.let { (it as? FrameLayout)?.removeView(old) }
            old.destroy()
        }
        bannerAdView = null
        activity.updateBannerPadding(false, bannerPosition == "top")
    }

    fun setBannerPosition(position: String) {
        runOnUiThread {
            val pos = if (position.equals("top", ignoreCase = true)) "top" else "bottom"
            if (bannerPosition != pos) {
                bannerPosition = pos
                val adView = bannerAdView ?: return@runOnUiThread
                val parent = adView.parent as? FrameLayout
                if (parent != null) {
                    parent.removeView(adView)
                    attachBanner(parent, adView)
                }
            }
        }
    }

    fun updateBannerMargins() {
        runOnUiThread {
            val adView = bannerAdView ?: return@runOnUiThread
            val isTop = bannerPosition == "top"
            val insets = activity.getSystemBarInsets()
            val actionBarHeight = activity.getTopActionBarHeight()
            (adView.layoutParams as? FrameLayout.LayoutParams)?.let { params ->
                params.gravity = (if (isTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
                if (isTop) {
                    params.topMargin = if (actionBarHeight > 0) actionBarHeight else insets.top
                    params.bottomMargin = 0
                } else {
                    params.topMargin = 0
                    params.bottomMargin = insets.bottom
                }
                adView.layoutParams = params
            }
        }
    }

    private fun attachBanner(root: FrameLayout, adView: AdView) {
        if (adView.parent != null) return
        val isTop = bannerPosition == "top"
        val insets = activity.getSystemBarInsets()
        val actionBarHeight = activity.getTopActionBarHeight()
        val params = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = (if (isTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
            if (isTop) {
                topMargin = if (actionBarHeight > 0) actionBarHeight else insets.top
            } else {
                bottomMargin = insets.bottom
            }
        }
        root.addView(adView, params)
        activity.updateBannerPadding(true, isTop)
    }

    // --- Interstitial ---

    fun loadInterstitial(adUnitId: String) {
        if (!isEnabled) {
            emitAdError("adFailedToLoad", "AdMob not configured", "interstitial")
            return
        }
        runOnUiThread {
            InterstitialAd.load(activity, adUnitId, buildAdRequest(), object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    ad.fullScreenContentCallback = fullScreenCallback("interstitial", adUnitId)
                    emit("adLoaded", adEventJson("interstitial", adUnitId))
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    emit("adFailedToLoad", adEventJson("interstitial", adUnitId).apply {
                        put("code", error.code)
                        put("message", error.message)
                    })
                }
            })
        }
    }

    fun showInterstitial() {
        if (!isEnabled) {
            emitAdError("adFailedToShow", "AdMob is disabled in Project Settings (Step 8: Ads). Please enable AdMob to display ads.", "interstitial")
            return
        }
        if (!canShowInterstitialNow()) {
            emit("adSkipped", adEventJson("interstitial", "").apply {
                put("reason", "frequency_capped")
            })
            return
        }
        runOnUiThread {
            val ad = interstitialAd
            val id = interstitialId
            if (ad != null) {
                lastInterstitialShowTime = System.currentTimeMillis()
                ad.show(activity)
            } else {
                if (id != null) {
                    loadInterstitial(id)
                    emit("adFailedToShow", adEventJson("interstitial", id).apply {
                        put("message", "Interstitial ad is loading in background. Please try again in a few seconds.")
                    })
                } else {
                    emit("adFailedToShow", adEventJson("interstitial", "").apply {
                        put("message", "Interstitial ad is not enabled in Project Settings.")
                    })
                }
            }
        }
    }

    private fun canShowInterstitialNow(): Boolean {
        val intervalMs = config.admobInterstitialIntervalSeconds * 1000L
        if (intervalMs <= 0) return true
        return System.currentTimeMillis() - lastInterstitialShowTime >= intervalMs
    }

    private fun scheduleAutoShowInterstitial() {
        val intervalMs = config.admobInterstitialIntervalSeconds * 1000L
        if (intervalMs > 0) {
            mainHandler.postDelayed(autoShowRunnable, intervalMs)
        }
    }

    private fun autoShowInterstitialTick() {
        val id = interstitialId ?: return
        if (canShowInterstitialNow()) {
            if (interstitialAd != null) {
                showInterstitial()
            } else {
                loadInterstitial(id)
            }
        }
        scheduleAutoShowInterstitial()
    }

    // Called from WebViewActivity on each page load
    fun onPageLoaded() {
        val pageCount = config.admobInterstitialPageCount
        if (pageCount <= 0) return
        pageLoadCounter++
        if (pageLoadCounter >= pageCount) {
            pageLoadCounter = 0
            val id = interstitialId ?: return
            if (interstitialAd != null) {
                showInterstitial()
            } else {
                loadInterstitial(id)
            }
        }
    }

    // --- Rewarded ---

    fun loadRewarded(adUnitId: String) {
        if (!isEnabled) {
            emitAdError("adFailedToLoad", "AdMob not configured", "rewarded")
            return
        }
        runOnUiThread {
            RewardedAd.load(activity, adUnitId, buildAdRequest(), object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    ad.fullScreenContentCallback = fullScreenCallback("rewarded", adUnitId)
                    emit("adLoaded", adEventJson("rewarded", adUnitId))
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    emit("adFailedToLoad", adEventJson("rewarded", adUnitId).apply {
                        put("code", error.code)
                        put("message", error.message)
                    })
                }
            })
        }
    }

    fun showRewarded(customCallback: String? = null) {
        runOnUiThread {
            if (!isEnabled) {
                emitAdError("adFailedToShow", "AdMob is disabled in Project Settings (Step 8: Ads). Please enable AdMob to display ads.", "rewarded")
                return@runOnUiThread
            }
            val ad = rewardedAd
            val id = rewardedId
            if (ad != null) {
                ad.show(activity, OnUserEarnedRewardListener { reward ->
                    val data = JSONObject().apply {
                        put("type", reward.type)
                        put("amount", reward.amount)
                    }
                    emit("rewardEarned", data)
                    customCallback?.let { cb ->
                        val script = "window.${cb} && window.${cb}(${reward.amount}, ${JSONObject.quote(reward.type)})"
                        activity.webView.evaluateJavascript(script, null)
                    }
                })
            } else {
                if (id != null) {
                    loadRewarded(id)
                    emit("adFailedToShow", adEventJson("rewarded", id).apply {
                        put("message", "Rewarded ad is loading in background. Please try again in a few seconds.")
                    })
                } else {
                    emit("adFailedToShow", adEventJson("rewarded", "").apply {
                        put("message", "Rewarded ad is not enabled in Project Settings.")
                    })
                }
            }
        }
    }

    // --- Lifecycle ---

    fun onPause() {
        mainHandler.removeCallbacks(autoShowRunnable)
        bannerAdView?.pause()
    }

    fun onResume() {
        bannerAdView?.resume()
        scheduleAutoShowInterstitial()
    }

    fun destroy() {
        mainHandler.removeCallbacks(autoShowRunnable)
        runOnUiThread {
            removeBanner()
            interstitialAd = null
            rewardedAd = null
        }
    }

    // --- Helpers ---

    private fun fullScreenCallback(type: String, adUnitId: String): com.google.android.gms.ads.FullScreenContentCallback {
        return object : com.google.android.gms.ads.FullScreenContentCallback() {
            override fun onAdClicked() {}
            override fun onAdDismissedFullScreenContent() {
                emit("adDismissed", adEventJson(type, adUnitId))
                if (type == "interstitial") {
                    interstitialAd = null
                    val id = interstitialId
                    if (id != null && (config.admobAutoLoadInterstitial || config.admobInterstitialIntervalSeconds > 0 || config.admobInterstitialPageCount > 0)) {
                        loadInterstitial(id)
                    }
                }
                if (type == "rewarded") {
                    rewardedAd = null
                    val id = rewardedId
                    if (id != null && (config.admobAutoLoadRewarded || config.admobRewardedEnabled)) {
                        loadRewarded(id)
                    }
                }
            }

            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                emit("adFailedToShow", adEventJson(type, adUnitId).apply {
                    put("code", error.code)
                    put("message", error.message)
                })
                if (type == "interstitial") {
                    interstitialAd = null
                    interstitialId?.let { loadInterstitial(it) }
                }
                if (type == "rewarded") {
                    rewardedAd = null
                    rewardedId?.let { loadRewarded(it) }
                }
            }

            override fun onAdImpression() {}
            override fun onAdShowedFullScreenContent() {
                emit("adShowedFullScreenContent", adEventJson(type, adUnitId))
            }
        }
    }

    private fun adEventJson(type: String, adUnitId: String): JSONObject {
        return JSONObject().apply {
            put("type", type)
            put("adUnitId", adUnitId)
        }
    }

    private fun emitAdError(event: String, message: String, type: String) {
        emit(event, adEventJson(type, "").apply { put("message", message) })
    }
}
