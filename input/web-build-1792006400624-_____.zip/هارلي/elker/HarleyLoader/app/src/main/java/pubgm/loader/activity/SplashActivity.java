package pubgm.loader.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import pubgm.loader.R;
import android.os.Looper;


import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {


  //  public static boolean mahyong = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
              //  mahyong = true;
                Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        }, 600);
    }
}
