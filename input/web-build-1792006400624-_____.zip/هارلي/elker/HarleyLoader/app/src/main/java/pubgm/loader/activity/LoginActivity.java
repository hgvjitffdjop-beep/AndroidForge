package pubgm.loader.activity;

import static pubgm.loader.server.ApiServer.getOwner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.widget.EditText;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.skydoves.powerspinner.OnSpinnerItemSelectedListener;
import com.skydoves.powerspinner.PowerSpinnerView;

import java.util.Locale;

import pubgm.loader.Component.Prefs;
import pubgm.loader.R;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.Button;
import com.google.android.material.textfield.TextInputEditText;

import pubgm.loader.utils.ActivityCompat;

public class LoginActivity extends ActivityCompat {

    static {
        System.loadLibrary("client");
    }
    public static int REQUEST_OVERLAY_PERMISSION = 5469;
    private static final String USER = "USER";
    private static final String PASS = "PASS";
    public static boolean Kooontoool = true;
    
    public static String USERKEY, PASSKEY;
    EditText keyInput;
    MaterialButton pasteBtn;

    private Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        loadbahasa();
        super.onCreate(savedInstanceState);
        setLightStatusBar(this);
        setContentView(R.layout.activity_login);
        initDesign();
        OverlayPermision();
        
        TextInputEditText textUsername = findViewById(R.id.textUsername);
        MaterialButton pasteBtn = findViewById(R.id.pasteBtn);

        pasteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard.hasPrimaryClip()) {
                    ClipData clipData = clipboard.getPrimaryClip();
                    if (clipData != null && clipData.getItemCount() > 0) {
                        CharSequence pastedText = clipData.getItemAt(0).getText();
                        if (pastedText != null) {
                            textUsername.setText(pastedText.toString());
                        }
                    }
                }
            }
        });
    }

    public void initDesign() {
        prefs = Prefs.with(this);
        final Context m_Context = this;

        TextView textUsername = findViewById(R.id.textUsername);
        MaterialButton btnSignIn = findViewById(R.id.loginBtn);
        textUsername.setText(prefs.read(USER, ""));

        PowerSpinnerView powerSpinnerView = findViewById(R.id.bahasa);
        
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        String currentLang = sharedPreferences.getString("bahasa", "en");
        String[] languages = getResources().getStringArray(R.array.bahasa);
        
        int selectedIndex = 2;
        switch(currentLang) {
            case "zh": 
                powerSpinnerView.setHint(languages[0]);
                selectedIndex = 0;
                break;
            case "ar": 
                powerSpinnerView.setHint(languages[1]);
                selectedIndex = 1;
                break;
            case "en": 
                powerSpinnerView.setHint(languages[2]);
                selectedIndex = 2;
                break;
            case "uz": 
                powerSpinnerView.setHint(languages[3]);
                selectedIndex = 3;
                break;
        }
        
        powerSpinnerView.selectItemByIndex(selectedIndex);

        powerSpinnerView.setOnSpinnerItemSelectedListener(new OnSpinnerItemSelectedListener<String>() {
            @Override
            public void onItemSelected(int oldIndex, @Nullable String oldItem, int newIndex, String newItem) {
                String langCode = "en";
                switch (newIndex) {
                    case 0: langCode = "zh"; break;
                    case 1: langCode = "ar"; break;
                    case 2: langCode = "en"; break;
                }

                SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("bahasa", langCode);
                editor.apply();
                
                powerSpinnerView.setHint(newItem);
                setLokasi(langCode);
                recreate();
            }
        });

        btnSignIn.setOnClickListener(v -> {
            TextView errorUsername = findViewById(R.id.error_username);

            if (!textUsername.getText().toString().isEmpty()) {
                prefs.write(USER, textUsername.getText().toString());

                String userKey = textUsername.getText().toString().trim();
                AlertDialog loadingDialog = showLoadingDialog();
                Login(LoginActivity.this, userKey, loadingDialog);
                USERKEY = userKey;
                errorUsername.setVisibility(View.GONE);
            } else {
                errorUsername.setText(getString(R.string.please_enter_username));
                errorUsername.setVisibility(View.VISIBLE);
            }
        });

        TextView getKey = findViewById(R.id.registerText);
        getKey.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(getOwner()));
            startActivity(intent);
        });
    }

    private void setLightStatusBar(Activity activity) {
        activity.getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
        activity.getWindow().setNavigationBarColor(Color.parseColor("#FFFFFF"));
    }

    public static void goLogin(Context context) {
        Intent i = new Intent(context, LoginActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }

    public void OverlayPermision() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
                builder.setMessage(R.string.please_allow_permision_floating);
                builder.setPositiveButton(R.string.yes, (p1, p2) -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                });
                builder.setCancelable(false);
                builder.show();
            }
        }
    }

    private static void Login(final Context m_Context, final String userKey, final AlertDialog loadingDialog) {
        final Handler loginHandler = new Handler(msg -> {
            loadingDialog.dismiss();
            if (msg.what == 0) {
                Intent i = new Intent(m_Context.getApplicationContext(), MainActivity.class);
                m_Context.startActivity(i);
            } else if (msg.what == 1) {
                new AlertDialog.Builder(m_Context, 5)
                        .setTitle("Key Error")
                        .setMessage(msg.obj.toString())
                        .setCancelable(false)
                        .setPositiveButton("OK", (dialog, which) -> System.exit(0))
                        .show();
            }
            return true;
        });

        new Thread(() -> {
            String result = suckmydick(m_Context, userKey);
            if (result.equals("OK")) {
                loginHandler.sendEmptyMessage(0);
            } else {
                Message msg = new Message();
                msg.what = 1;
                msg.obj = result;
                loginHandler.sendMessage(msg);
            }
        }).start();
    }

    private AlertDialog showLoadingDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.animation_login, null);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        dialog.show();
        return dialog;
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_STORAGE) {
            OverlayPermision();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            InstllUnknownApp();
        } else if (requestCode == REQUEST_MANAGE_UNKNOWN_APP_SOURCES) {
            if (!isPermissionGaranted()) {
                takeFilePermissions();
            }
        }
    }

    private void setLokasi(String lang) {
        if (lang == null || lang.isEmpty()) {
            lang = "en";
        }
        
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        
        Configuration config = new Configuration();
        config.locale = locale;
        config.setLayoutDirection(locale);
        
        Resources resources = getBaseContext().getResources();
        resources.updateConfiguration(config, resources.getDisplayMetrics());
        
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("bahasa", lang);
        editor.apply();
    }

    private void loadbahasa() {
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        String bahasa = sharedPreferences.getString("bahasa", "en");
        setLokasi(bahasa);
    }

    private static native String suckmydick(Context mContext, String userKey);
}