package pubgm.loader.activity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import pubgm.loader.BoxApplication;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import top.niunaijun.blackbox.utils.FileUtils;
import android.graphics.Color;
import static pubgm.loader.activity.LoginActivity.PASSKEY;
import static pubgm.loader.activity.LoginActivity.USERKEY;
import static pubgm.loader.activity.LoginActivity.Kooontoool;


import static pubgm.loader.server.ApiServer.FixCrash;
import static pubgm.loader.server.ApiServer.activity;
import static pubgm.loader.server.ApiServer.mainURL;
import pubgm.loader.utils.UiKit;
import java.util.List;
import java.util.Locale;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;

import com.google.android.material.button.MaterialButton;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import androidx.appcompat.app.AlertDialog;
import pubgm.loader.utils.PermissionUtils;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;

import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import pubgm.loader.Component.DownloadZip;
import pubgm.loader.Component.Downtwo;
import pubgm.loader.Component.SharedPreferencesManager;
import pubgm.loader.R;
import pubgm.loader.floating.FloatService;
import pubgm.loader.floating.Overlay;
import pubgm.loader.floating.ToggleAim;
import pubgm.loader.floating.ToggleBullet;
import pubgm.loader.floating.ToggleSimulation;


import pubgm.loader.utils.FLog;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.topjohnwu.superuser.Shell;
import android.view.LayoutInflater;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import pubgm.loader.utils.ActivityCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;

import androidx.appcompat.app.AlertDialog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Set;
import static top.niunaijun.blackbox.core.env.BEnvironment.getDataFilesDir;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;
import android.os.AsyncTask;
import java.util.TimeZone;
import android.widget.ProgressBar;
import android.widget.TextView;

import android.os.Environment;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import android.view.Gravity;

import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class MainActivity extends ActivityCompat {

    
    public static String socket;
    public static String daemonPath;
    public static boolean check = false;
    public static int hiderecord = 0;
    static MainActivity instance;
    private TextView bmode,safe_txt;
    public String verPath;


    static {
            System.loadLibrary("client");
    }

    Context ctx;
    InstallResult installResult;
    BlackBoxCore blackboxCore;
    public static native String EXP();
    public static String TimeExpired;
    private static final String APP_SECRET = "RAYAN_SYED_UNIQUE_KEY_2025";
    public native boolean checkAppSignature(String key);


    private static final int REQUEST_PERMISSIONS = 1;
    private static final String PREF_NAME = "espValue";
    private SharedPreferences sharedPreferences;
    String[] appPackage = {"com.tencent.ig", "com.pubg.krmobile", "com.pubg.imobile", "com.rekoo.pubgm", "com.facebook.katana", "com.vng.pubgmobile", "com.twitter.android", "mark.via.gp"};
    public String nameGame = "PROTECTION GLOBAL";
    public String CURRENT_PACKAGE = "";
    public LinearProgressIndicator progres;
    public CardView enable, disable;
    public static int gameint = 1;
    public static String bypassmode = "Automatic";
    public static int bitversi = 64;
    public static boolean noroot = false;
    public static int device = 1;
    public static String game = "com.tencent.ig";
    TextView root;
    public static boolean kernel = false;
    public static boolean Ischeck = false;
    public static boolean modestatus = false;
    public LinearLayout container;
      static boolean isLibLoaded = false;
    public static String modeselect;
    public static String typelogin;
    
    
    public static MainActivity get() {
        return instance;
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        blackboxCore = BlackBoxCore.get();
        blackboxCore.doCreate();

        setContentView(R.layout.activity_navigation);

        CountTimerAccout();

        init();

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        ctx = this;

        initMenu1();
        initMenu2();
        Loadssets();
        devicecheck();
        SettingESP();

        instance = this;
        isLogin = true;
        Checking();

        Makedir();
        updateButtonColorsBasedOnInstallation();

        if (!checkAppSignature(APP_SECRET)) {
            showCrackerNotice();
        }
    }

        private void showCrackerNotice() {
        new AlertDialog.Builder(this)
                .setTitle("Verification Failed")
                .setMessage("Fool cracker 😂")
                .setCancelable(false)
                .show();

        new Handler().postDelayed(() -> {
            finishAffinity();
            System.exit(0);
        }, 3000);
    }

        
        
        
    

    public void devicecheck(){
        
        
        if (Shell.rootAccess()){
            FLog.info("Root granted");
            modeselect =   "ROOT MODE " + "ANDROID " + Build.VERSION.RELEASE;
            root.setText(getString(R.string.root) );
            Ischeck = true;
            noroot = true;
            device = 1;
        } else {
            FLog.info("Root not granted");
            modeselect =   "CONTAINER MODE " + "ANDROID " + Build.VERSION.RELEASE;
            Ischeck = false;
            device = 2;
        }
    }


    public void Checking(){
        
                new DownloadZip(this).execute("1", mainURL());
        }







    @SuppressLint("SetTextI18n")
    public void initMenu1() {
    MaterialButton esp64Button = findViewById(R.id.esp64);
    MaterialButton esp32Button = findViewById(R.id.esp32);
    MaterialButton systemModeBtn = findViewById(R.id.system);
    MaterialButton kernelModeBtn = findViewById(R.id.kernel);
    MaterialButton espsafe = findViewById(R.id.espsafe);
    MaterialButton espunsafe = findViewById(R.id.espunsafe);
    MaterialButton InstallBgmiBtn = findViewById(R.id.InstallBgmi);
    MaterialButton InstallGlobalBtn = findViewById(R.id.InstallGlobal);
    MaterialButton InstallKRBtn = findViewById(R.id.InstallKR);
    MaterialButton InstallVNGBtn = findViewById(R.id.InstallVNG);
    MaterialButton InstallTWBtn = findViewById(R.id.InstallTW);
    MaterialButton InstallTRBtn = findViewById(R.id.InstallTR);
setupTwitterButton(InstallTRBtn, "com.twitter.android");

        setupButton(InstallGlobalBtn, appPackage[0]);
setupButton(InstallKRBtn, appPackage[1]);
setupButton(InstallBgmiBtn, appPackage[2]);
setupButton(InstallTWBtn, appPackage[3]);
setupButton(InstallVNGBtn, appPackage[5]);




       MaterialButton FixObbError = findViewById(R.id.FixObb);
FixObbError.setOnClickListener(v -> {
    showFixObbCustomDialog();
});



        if (Shell.rootAccess()) {
            InstallBgmiBtn.setText("START");
            InstallGlobalBtn.setText("START");
            InstallKRBtn.setText("START");
            InstallVNGBtn.setText("START");
            InstallTWBtn.setText("START");

        } else {

        }







}







    @SuppressLint("ResourceAsColor")
    void initMenu2() {
        TextView username = findViewById(R.id.username);
        TextView leveluser = findViewById(R.id.leveluser);

        username.setText(PASSKEY + ":" + USERKEY);

        if (Kooontoool) {
            leveluser.setText("PREMIUM");
        } else {
            leveluser.setText("FREE");
            findViewById(R.id.hiderecord).setAlpha(0.5f);
        }

        MaterialButton play = findViewById(R.id.play);
        final boolean[] isMenuVisible = {false};

        play.setOnClickListener(v -> {
            if (!isMenuVisible[0]) {
                play.setIcon(getResources().getDrawable(R.drawable.pause));
                play.setText("CLOSE");
                play.setIconTint(getResources().getColorStateList(R.color.livaiamk));
                play.setTextColor(getResources().getColor(R.color.livaiamk));
                startFloater();
                isMenuVisible[0] = true;
            } else {
                play.setIcon(getResources().getDrawable(R.drawable.play));
                play.setText("PLAY");
                play.setIconTint(getResources().getColorStateList(R.color.green));
                play.setTextColor(getResources().getColor(R.color.green));
                stopPatcher();
                isMenuVisible[0] = false;
            }
        });

        SharedPreferences sharedPreferences = getSharedPreferences("espValue", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        int savedHideRecord = sharedPreferences.getInt("hiderecord", 0);
        MaterialButton hideRecordButton = findViewById(R.id.hiderecord);

        if (savedHideRecord == 1) {
            hideRecordButton.setTextColor(getResources().getColor(R.color.green));
            hideRecordButton.setIconTintResource(R.color.green);
        } else {
            hideRecordButton.setTextColor(getResources().getColor(R.color.livaiamk));
            hideRecordButton.setIconTintResource(R.color.livaiamk);
        }

        findViewById(R.id.hiderecord).setOnClickListener(v -> {
            if (Kooontoool) {
                showBottomSheetDialog(
                        getResources().getDrawable(R.drawable.icon_toast_alert),
                        getString(R.string.confirm),
                        getString(R.string.want_remove_it),
                        false,
                        sv -> {
                            hiderecord = 1;
                            hideRecordButton.setTextColor(getResources().getColor(R.color.green));
                            hideRecordButton.setIconTintResource(R.color.green);
                            editor.putInt("hiderecord", 1).apply();
                            dismissBottomSheetDialog();
                        },
                        v1 -> {
                            hiderecord = 0;
                            hideRecordButton.setTextColor(getResources().getColor(R.color.livaiamk));
                            hideRecordButton.setIconTintResource(R.color.livaiamk);
                            editor.putInt("hiderecord", 0).apply();
                            dismissBottomSheetDialog();
                        }
                );
            } else {
                toastImage(R.drawable.notife, "Please Upgrade to PREMIUM");
            }
        });
    }
private void setupTwitterButton(MaterialButton button, String packageName) {
    button.setOnClickListener(v -> {
        boolean isInstalled = blackboxCore.isInstalled(packageName, 0);

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_options, null);

        TextView launch = dialogView.findViewById(R.id.optionLaunch);
        TextView install = dialogView.findViewById(R.id.optionInstall);
        TextView uninstall = dialogView.findViewById(R.id.optionUninstall);

        launch.setVisibility(isInstalled ? View.VISIBLE : View.GONE);
        uninstall.setVisibility(isInstalled ? View.VISIBLE : View.GONE);
        install.setVisibility(isInstalled ? View.GONE : View.VISIBLE);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        launch.setOnClickListener(v1 -> {
            blackboxCore.launchApk(packageName, 0);
            dialog.dismiss();
            Toast.makeText(this, "Launching Twitter...", Toast.LENGTH_SHORT).show();
        });

        install.setOnClickListener(v2 -> {
            blackboxCore.installPackageAsUser(packageName, 0);
            Toast.makeText(this, "Installing Twitter...", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        uninstall.setOnClickListener(v3 -> {
            dialog.dismiss();
            new AlertDialog.Builder(this)
                    .setTitle("Confirm Uninstall")
                    .setMessage("Do you want to uninstall Twitter?")
                    .setPositiveButton("Yes", (confirmDialog, which) -> {
                        blackboxCore.uninstallPackageAsUser(packageName, 0);
                        Toast.makeText(this, "Twitter Uninstalled", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        dialog.show();
    });
}


private void setupButton(MaterialButton button, String packageName) {
    button.setOnClickListener(v -> {
        boolean isInstalled = blackboxCore.isInstalled(packageName, 0);

        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_options, null);

        TextView launch = dialogView.findViewById(R.id.optionLaunch);
        TextView install = dialogView.findViewById(R.id.optionInstall);
        TextView uninstall = dialogView.findViewById(R.id.optionUninstall);

        launch.setVisibility(isInstalled ? View.VISIBLE : View.GONE);
        uninstall.setVisibility(isInstalled ? View.VISIBLE : View.GONE);
        install.setVisibility(isInstalled ? View.GONE : View.VISIBLE);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        launch.setOnClickListener(v1 -> {
            blackboxCore.launchApk(packageName, 0);
            startFloater();
            dialog.dismiss();

            bypass();
            
        });

        install.setOnClickListener(v2 -> {
            blackboxCore.installPackageAsUser(packageName, 0);

        });

        uninstall.setOnClickListener(v3 -> {
            dialog.dismiss();
            new AlertDialog.Builder(this)
                    .setTitle("Confirm Uninstall")
                    .setMessage("Are you sure you want to uninstall this app?")
                    .setPositiveButton("Yes", (confirmDialog, which) -> {
                        blackboxCore.uninstallPackageAsUser(packageName, 0);
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        dialog.show();
    });
}





    public void SettingESP(){
    
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                    REQUEST_PERMISSIONS);
        }

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);


        findViewById(R.id.savesetting).setOnClickListener(v -> {
            try {
                importSharedPreferences();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Failed to import", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.exportsetting).setOnClickListener(v -> {
            try {
                exportSharedPreferences();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Failed to export", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.resetsetting).setOnClickListener(v -> {
    new AlertDialog.Builder(this, R.style.PlainDialog)
        .setTitle("Reset Settings")
        .setMessage("It will reset all your saved ESP settings.\nAre you sure?")
        .setPositiveButton("Yes", (dialog, which) -> {
            resetSharedPreferences();
            Toast.makeText(MainActivity.this, "Successfully Reset", Toast.LENGTH_SHORT).show();
        })
        .setNegativeButton("No", null)
        .show();
});

    }

    private void exportSharedPreferences() throws IOException {
        File srcFile = new File(getApplication().getDataDir().toString() + "/shared_prefs/"+ PREF_NAME + ".xml");
        File dstFile = new File(Environment.getExternalStorageDirectory(), PREF_NAME + ".xml");

        if (srcFile.exists()) {
            FileChannel src = null;
            FileChannel dst = null;
            try {
                src = new FileInputStream(srcFile).getChannel();
                dst = new FileOutputStream(dstFile).getChannel();
                dst.transferFrom(src, 0, src.size());
                Toast.makeText(MainActivity.this, "Exported to " + dstFile.getAbsolutePath(), Toast.LENGTH_SHORT).show();
            } finally {
                if (src != null) {
                    src.close();
                }
                if (dst != null) {
                    dst.close();
                }
            }
        } else {
            Toast.makeText(MainActivity.this, "Setting esp files file not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void importSharedPreferences() throws IOException {
        File srcFile = new File(Environment.getExternalStorageDirectory(), PREF_NAME + ".xml");
        File dstFile = new File(getApplication().getDataDir().toString() + "/shared_prefs/" + PREF_NAME + ".xml");

        if (srcFile.exists()) {
            FileChannel src = null;
            FileChannel dst = null;
            try {
                src = new FileInputStream(srcFile).getChannel();
                dst = new FileOutputStream(dstFile).getChannel();
                dst.transferFrom(src, 0, src.size());
                Toast.makeText(MainActivity.this, "Imported from " + srcFile.getAbsolutePath(), Toast.LENGTH_SHORT).show();
            } finally {
                if (src != null) {
                    src.close();
                }
                if (dst != null) {
                    dst.close();
                }
            }
        } else {
            Toast.makeText(MainActivity.this, "Setting esp file not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void resetSharedPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }

    void gameversion(LinearLayout a, LinearLayout b, LinearLayout c, LinearLayout d, LinearLayout e){
        a.setBackgroundResource(R.drawable.bgfituron);
        b.setBackgroundResource(R.drawable.bgfituroff);
        c.setBackgroundResource(R.drawable.bgfituroff);
        d.setBackgroundResource(R.drawable.bgfituroff);
        e.setBackgroundResource(R.drawable.bgfituroff);
    }


    void init() {
        
        
        LinearLayout menu1 = findViewById(R.id.imenu1);
        LinearLayout menu2 = findViewById(R.id.imenu2);
        
        
        
        

        

        
    }



private void showFixObbCustomDialog() {
    LayoutInflater inflater = LayoutInflater.from(this);
    View dialogView = inflater.inflate(R.layout.dialog_fix_obb, null);

    TextView gl = dialogView.findViewById(R.id.gameGl);
    TextView kr = dialogView.findViewById(R.id.gameKr);
    TextView vn = dialogView.findViewById(R.id.gameVn);
    TextView tw = dialogView.findViewById(R.id.gameTw);
    TextView bgmi = dialogView.findViewById(R.id.gameBgmi);

    AlertDialog dialog = new AlertDialog.Builder(this)
            .setView(dialogView)
            .create();

    View.OnClickListener listener = v -> {
        String pkg = "";
        int vcode = 0;

        switch (v.getId()) {
            case R.id.gameGl:
                pkg = "com.tencent.ig";
                vcode = 20325;
                break;
            case R.id.gameKr:
                pkg = "com.pubg.krmobile";
                vcode = 20325;
                break;
            case R.id.gameVn:
                pkg = "com.vng.pubgmobile";
                vcode = 20325;
                break;
            case R.id.gameTw:
                pkg = "com.rekoo.pubgm";
                vcode = 20325;
                break;
            case R.id.gameBgmi:
                pkg = "com.pubg.imobile";
                vcode = 20125;
                break;
        }

        String obbFileName = "main." + vcode + "." + pkg + ".obb";
        File destObb = new File("/storage/emulated/0/blackbox/Android/obb/" + pkg + "/" + obbFileName);

        if (destObb.exists()) {
            Toast.makeText(this, "OBB already installed for " + pkg, Toast.LENGTH_LONG).show();
        } else {
            String sourcePath = "/storage/emulated/0/Android/obb/" + pkg + "/" + obbFileName;
            new MyCopyTask().execute(sourcePath, pkg);
        }

        dialog.dismiss();
    };

    gl.setOnClickListener(listener);
    kr.setOnClickListener(listener);
    vn.setOnClickListener(listener);
    tw.setOnClickListener(listener);
    bgmi.setOnClickListener(listener);

    dialog.show();
}


    private void updateButtonColorsBasedOnInstallation() {
    MaterialButton InstallBgmiBtn = findViewById(R.id.InstallBgmi);
    MaterialButton InstallGlobalBtn = findViewById(R.id.InstallGlobal);
    MaterialButton InstallKRBtn = findViewById(R.id.InstallKR);
    MaterialButton InstallVNGBtn = findViewById(R.id.InstallVNG);
    MaterialButton InstallTWBtn = findViewById(R.id.InstallTW);
    MaterialButton InstallTRBtn = findViewById(R.id.InstallTR);

    String[] packageNames = {
        "com.pubg.imobile",
        "com.tencent.ig",
        "com.pubg.krmobile",
        "com.vng.pubgmobile",
        "com.rekoo.pubgm",
        "com.twitter.android"
    };

    MaterialButton[] buttons = {
        InstallBgmiBtn,
        InstallGlobalBtn,
        InstallKRBtn,
        InstallVNGBtn,
        InstallTWBtn,
        InstallTRBtn
    };

    int lightBlueColor = ContextCompat.getColor(this, R.color.buttonon);


    for (int i = 0; i < packageNames.length; i++) {
        if (blackboxCore.isInstalled(packageNames[i], 0)) {
            buttons[i].setBackgroundColor(lightBlueColor);
        } else {
            buttons[i].setBackgroundColor(Color.TRANSPARENT);
        }
    }
}



    void Makedir() {
        if (!Shell.rootAccess()) {
            File GlobalFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.tencent.ig/");
            File KoreaFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.pubg.krmobile/");
            File BgmiFolder = new File("/storage/emulated/0/blackbox/Android/obb/com.pubg.imobile/");
            if (GlobalFolder.exists()) {

            } else if (!GlobalFolder.exists()) {
                GlobalFolder.mkdirs();
                KoreaFolder.mkdirs();
                BgmiFolder.mkdirs();
            }
        }
    }



    
    

    private class MyCopyTask extends AsyncTask<String, Integer, File> {
    AlertDialog dialog;
    String message;
    ProgressBar progressBar;
    TextView progressText;

    @Override
    protected void onPreExecute() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this, R.style.WrapContentDialog);
        builder.setCancelable(false);
        View customLayout = getLayoutInflater().inflate(R.layout.dialog_progress, null);
        progressBar = customLayout.findViewById(R.id.progressBar);
        progressText = customLayout.findViewById(R.id.progressText);
        progressBar.setProgress(0);
        progressText.setText("0%");
        builder.setView(customLayout);
        dialog = builder.create();
        dialog.show();
    }

    @Override
    protected File doInBackground(String... params) {
        String sourcePath = params[0];
        File source = new File(sourcePath);
        String filename = sourcePath.substring(sourcePath.lastIndexOf("/") + 1);
        File destination = new File("/storage/emulated/0/blackbox/Android/obb/" + params[1] + "/" + filename);

        try {
            copyFileWithProgress(source, destination);
        } catch (IOException e) {
            message = e.getMessage();
        }
        return destination;
    }

    private void copyFileWithProgress(File source, File destination) throws IOException {
        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(destination)) {

            long total = source.length();
            long copied = 0;
            byte[] buffer = new byte[4096];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
                copied += read;

                int progress = (int)((copied * 100) / total);
                publishProgress(progress);
            }
        }
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
        int progress = values[0];
        if (progressBar != null) {
            progressBar.setProgress(progress);
        }
        if (progressText != null) {
            progressText.setText(progress + "%");
        }
    }

    @Override
    protected void onPostExecute(File result) {
        if (result.exists()) {
            Toast.makeText(getApplicationContext(), R.string.obb_copied, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
        }
        dialog.dismiss();
    }
}


    void RunShell(String cmd) {
        try {
            Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    void runant(final String nf){
        excpp("/"+nf);
		}

	private void ExecuteElf(String shell) {
	try {
	Runtime.getRuntime().exec(shell);

        } catch (Exception e) {
            e.printStackTrace();
			}
			}
			public void excpp(String path) {
			try {
					ExecuteElf("chmod 777 " + getFilesDir() + path);
					ExecuteElf(getFilesDir() + path);
						ExecuteElf("su -c chmod 777 " + getFilesDir() + path);
						ExecuteElf("su -c " + getFilesDir() + path);
					} catch (Exception e) {

        }
			}

    private void Loadssets() {
        MoveAssets(getFilesDir() + "/", "socs64");
        MoveAssets(getFilesDir() + "/", "socu64");
        MoveAssets(getFilesDir() + "/", "socs32");
        MoveAssets(getFilesDir() + "/", "socu32");
        MoveAssets(getFilesDir() + "/", "TW");
        MoveAssets(getFilesDir() + "/", "akram");
        MoveAssets(getFilesDir() + "/", "N5LA");
        MoveAssets(getFilesDir() + "/", "VNG");
        MoveAssets(getFilesDir() + "/", "HakmeDev");
        MoveAssets(getFilesDir() + "/", "kernels64");
    }

    private boolean MoveAssets(String outPath, String fileName) {
        File file = new File(outPath);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("--Method--", "copyAssetsSingleFile: cannot create directory.");
                return false;
            }
        }
        try {
            InputStream inputStream = getAssets().open(fileName);
            File outFile = new File(file, fileName);
            FileOutputStream fileOutputStream = new FileOutputStream(outFile);
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = inputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            inputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String loadJSONFromAsset(String fileName) {
        String json = null;
        try {
            InputStream is = getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        stopService(new Intent(MainActivity.get(), FloatService.class));
        stopService(new Intent(MainActivity.get(), Overlay.class));
        
        stopService(new Intent(MainActivity.get(), ToggleBullet.class));
        stopService(new Intent(MainActivity.get(), ToggleAim.class));
        stopService(new Intent(MainActivity.get(), ToggleSimulation.class));
finishAffinity();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this, getString(R.string.please_click_icon_logout_for_exit), Toast.LENGTH_SHORT).show();
    }
    
    
    
    



    public LinearProgressIndicator getProgresBar() {
        if (progres == null) {
            progres = findViewById(R.id.progress);
        }
        return progres;
    }

    public void doShowProgress(boolean indeterminate) {
        if (progres == null) {
            return;
        }
        progres.setVisibility(View.VISIBLE);
        progres.setIndeterminate(indeterminate);

        if (!indeterminate) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                progres.setMin(0);
            }
            progres.setMax(100);
        }
    }

    public void doHideProgress() {
        if (progres == null) {
            return;
        }
        progres.setIndeterminate(true);
        progres.setVisibility(View.GONE);
    }

    

    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (FloatService.class.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    private void startPatcher() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(MainActivity.get())) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 123);
            } else {
                startFloater();
            }
        }
    }

    private void startFloater() {
        
            startService(new Intent(MainActivity.get(), FloatService.class));
            loadAssets();
        } 
        
    private void stopPatcher() {
        stopService(new Intent(MainActivity.get(), FloatService.class));
        stopService(new Intent(MainActivity.get(), Overlay.class));
        stopService(new Intent(MainActivity.get(), ToggleAim.class));
        stopService(new Intent(MainActivity.get(), ToggleBullet.class));
        stopService(new Intent(MainActivity.get(), ToggleSimulation.class));
    }

    public void loadAssets() {
		String filepath =Environment.getExternalStorageDirectory() + "/Android/data/.tyb";
        FileOutputStream fos = null;
        try {
			fos = new FileOutputStream(filepath);
			byte[] buffer = "DO NOT DELETE".getBytes();
			fos.write(buffer, 0, buffer.length);
			fos.close();
        } catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		daemonPath =getFilesDir().toString() +"/socu64";
		if(Shell.rootAccess()) {
			socket = "su -c " + daemonPath;
		} else {
			socket = daemonPath;
		}
		try {
			Runtime.getRuntime().exec("chmod 777 " + daemonPath);
		} catch (IOException e) {
		}
	}

    @Override
    protected void onResume() {
        super.onResume();
        boolean needsRecreate = getSharedPreferences("app_prefs", MODE_PRIVATE)
                .getBoolean("needs_recreate", false);
        if (needsRecreate) {
            getSharedPreferences("app_prefs", MODE_PRIVATE)
                    .edit()
                    .putBoolean("needs_recreate", false)
                    .apply();
        }
    }


public void bypass() {
    Handler handler = new Handler(Looper.getMainLooper());

    handler.postDelayed(() -> {
        runant("/akram");
        
        handler.postDelayed(() -> {
            runant("/akram");

            handler.postDelayed(() -> {
                runant("/akram");
            }, 38_000);

        }, 30_000);

    }, 20_000);
}

private void CountTimerAccout() {
    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            try {
                handler.postDelayed(this, 1000);
                TimeExpired = EXP();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                Date expiryDate = dateFormat.parse(TimeExpired);
                long now = System.currentTimeMillis();
                long distance = expiryDate.getTime() - now;

                long days = distance / (24 * 60 * 60 * 1000);
                long hours = (distance / (60 * 60 * 1000)) % 24;
                long minutes = (distance / (60 * 1000)) % 60;
                long seconds = (distance / 1000) % 60;

                if (distance >= 0) {
                    TextView Hari = findViewById(R.id.tv_d);
                    TextView Jam = findViewById(R.id.tv_h);
                    TextView Menit = findViewById(R.id.tv_m);
                    TextView Detik = findViewById(R.id.tv_s);

                    Hari.setText(String.format("%02d", days));
                    Jam.setText(String.format("%02d", hours));
                    Menit.setText(String.format("%02d", minutes));
                    Detik.setText(String.format("%02d", seconds));
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };
    handler.postDelayed(runnable, 0);
}


    
}

